<?php
include 'userlogin/conn.php';
?>


<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Services Page </title>
      <!-- Favicon -->
      <!-- Bootstrap CSS -->
       <!-- Font Awesome CDN -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

      <link href="assets/css/bootstrap.min.css" rel="stylesheet">
      <!-- Animate CSS -->
      <link href="assets/vendors/animate/animate.css" rel="stylesheet">
      <!-- Icon CSS-->
      <link rel="stylesheet" href="assets/vendors/font-awesome/css/font-awesome.min.css">
      <!-- Owlcarousel CSS-->
      <link rel="stylesheet" type="text/css" href="assets/vendors/owl_carousel/owl.carousel.css" media="all">
      <!--Template Styles CSS-->
      <link rel="stylesheet" type="text/css" href="assets/css/style.css" media="all" />
      <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600,600i,700,700i,800,800i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese" rel="stylesheet">
   </head>
   <body>
      <div class="service-banner-img  ">
         <div class="ovrllay">
            <!-- Header_Area -->
             <nav class="navbar navbar-default header_aera affix-top">
    <div class="container m-s">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="col-md-4 p0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                    data-target="#min_navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand logo-biss" href="index.html"> Star Law Firm </a>
            </div>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="col-md-8 p0">
            <div class="collapse navbar-collapse" id="min_navbar">
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown submenu">
                        <a href="index.php" class="">Home</a>
                    </li>
                    <li class="dropdown submenu">
                        <a href="about.php" class="">About</a>
                    </li>
                    <li class="dropdown submenu">
                        <a href="services.php" class=""> Services</a>
                    </li>
                    <li><a href="findlawyer.php"><i class="fa-solid fa-magnifying-glass"></i> Find a Lawyer</a></li>

                    <li class="dropdown submenu">
                        <a href="contact.php" class="">Contact</a>
                    </li>
                    <?php if (isset($_SESSION['user_email'])): ?>
                    <!-- If logged in, show logout -->
                    <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                    <?php else: ?>
                    <!-- Show login options -->
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <i class="fas fa-user"></i> Login <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="userlogin/login.php" style="color: black;">As Client</a></li>
                            <li><a href="userlogin/login.php">As Lawyer</a></li>
                            <li><a href="admin_login.php">As Admin</a></li>
                        </ul>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
    </div>
    <!-- /.container -->
</nav>
            <!-- End Header_Area -->
            <!-- #banner start -->
            <section id="banner" class="py-70" >
               <div class="container ">
                  <div class="row py-70 ">
                     <!-- #banner-text start -->            
                     <div id="banner-text" class="col-md-12 text-c  ">
                        <div class="left-borders">
                           <h5 class="wow fadeInUp main-about_h" data-wow-delay="0.2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">PRACTICE AREAS</h5>
                           <p class="banner-text wow fadeInUp main-h3" data-wow-delay="0.8s" style="visibility: visible; animation-delay: 0.8s; animation-name: fadeInUp;"><span class="c_yellow"> PRACTICE AREAS
                              </span>  | ORR <br>AND ITS ATTORNEYS 
                           </p>
                        </div>
                     </div>
                     <!-- /#banner-text End -->
                  </div>
               </div>
            </section>
         </div>
      </div>
      <!-- /#banner end -->
      <!--#service Area start -->
      <div  id="about">
      <div class="container-fluid">
         <div class="row ">
            <div class=" col-md-4 bg_color">
               <div class="Solid-Law">
                  <h1>We Provide Solid <br>  Law Practice    </h1>
                  <p> We are dedicated to your best interests. Our nationally recognized law firm has the experience, ingenuity,  looking for.     </p>
                  <a href=""> READ MORE </a>
               </div>
            </div>
            <div class=" col-md-4 bg_color2">
               <div class="Solid-Law">
                  <h1>Aggressive Criminal <br>Defense   </h1>
                  <p> We are dedicated to your best interests. Our nationally recognized law firm has the experience, ingenuity,   looking for.      </p>
                  <a href=""> READ MORE </a>
               </div>
            </div>
            <div class=" col-md-4 bg_color3">
               <div class="Solid-Law">
                  <h1>Experienced Court <br> Performance    </h1>
                  <p> We are dedicated to your best interests. Our nationally recognized law firm has the experience, ingenuity, looking for.     </p>
                  <a href=""> READ MORE </a>
               </div>
            </div>
         </div>
      </div>
      <!--#service Area End-->
      <!-- #service Area start -->
      <div  id="about"  class=" py-70 bg_gradient_team">
         <div class="container">
            <div class="row text-center mb-60 ">
               <div class="title wow fadeInUp">
                  <h1>Practice Areas</h1>
                  <div class="hed_img"> 
                     <img src="assets/images/headding-img.png">
                  </div>
                  <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem <br> Ipsum has been the industry's standard.  </p>
               </div>
            </div>
            <div class="row about_row  py-40">
               <!--#about-text start --> 
               <div class="who_we_area col-md-4 col-sm-6 col-4pad wow fadeInUp">
                  <div class="service-s">
                     <div class="servise-top wow fadeInUp">
                        <img src="assets/images/service1.png">
                     </div>
                     <h2 class="Practice"> Criminal Law </h2>
                     <p class="bottom-s">Our criminal defense attorneys will <br>protect your rights in court. </p>
                     <div class="button-div">
                        <a href="" class="button-buttom"> read more   </a>
                     </div>
                  </div>
               </div>
               <div class="who_we_area col-md-4 col-sm-6 col-4pad wow fadeInUp">
                  <div class="service-s">
                     <div class="servise-top wow fadeInUp">
                        <img src="assets/images/service2.png">
                     </div>
                     <h2 class="Practice"> Property Law </h2>
                     <p class="bottom-s">Our criminal defense attorneys will <br>protect your rights in court.  </p>
                     <div class="button-div">
                        <a href="" class="button-buttom"> read more   </a>
                     </div>
                  </div>
               </div>
               <div class="who_we_area col-md-4 col-sm-6 col-4pad wow fadeInUp">
                  <div class="service-s">
                     <div class="servise-top wow fadeInUp">
                        <img src="assets/images/service3.png">
                     </div>
                     <h2 class="Practice"> Personal Injury </h2>
                     <p class="bottom-s">Our criminal defense attorneys will <br>protect your rights in court.  </p>
                     <div class="button-div">
                        <a href="" class="button-buttom"> read more   </a>
                     </div>
                  </div>
               </div>
               <!--#End about-text  --> 
            </div>
            <div class="row mt-50  py-40">
               <!--#about-text start --> 
               <div class="who_we_area col-md-4 col-sm-6 col-4pad wow fadeInUp">
                  <div class="service-s">
                     <div class="servise-top wow fadeInUp">
                        <img src="assets/images/service4.png">
                     </div>
                     <h2 class="Practice"> Commercial  Law </h2>
                     <p class="bottom-s">Our criminal defense attorneys will <br>protect your rights in court. </p>
                     <div class="button-div">
                        <a href="" class="button-buttom"> read more   </a>
                     </div>
                  </div>
               </div>
               <div class="who_we_area col-md-4 col-sm-6 col-4pad wow fadeInUp">
                  <div class="service-s">
                     <div class="servise-top wow fadeInUp">
                        <img src="assets/images/service5.png">
                     </div>
                     <h2 class="Practice">Money Laundering   </h2>
                     <p class="bottom-s">Our criminal defense attorneys will <br>protect your rights in court.  </p>
                     <div class="button-div">
                        <a href="" class="button-buttom"> read more   </a>
                     </div>
                  </div>
               </div>
               <div class="who_we_area col-md-4 col-sm-6 col-4pad wow fadeInUp">
                  <div class="service-s">
                     <div class="servise-top wow fadeInUp">
                        <img src="assets/images/service6.png">
                     </div>
                     <h2 class="Practice"> Drug Offence </h2>
                     <p class="bottom-s">Our criminal defense attorneys will <br>protect your rights in court.  </p>
                     <div class="button-div">
                        <a href="" class="button-buttom"> read more   </a>
                     </div>
                  </div>
               </div>
               <!--#End about-text  --> 
            </div>
         </div>
      </div>
      <!-- End About Us Area -->
      <!--#Our Testimonial Area start-->
<div id="testimonials" class="testimonial_area py-70 bg_testimonial_img wow fadeInUp">
   <div class="container">
      <div class="row">
         <div class="col-md-7 text-left wow fadeInUp">
            <h1 class="testimonial_top"> What People Say </h1>
            <div class="testimonial_carosel">
               <div class="item">
                  <div class="media">
                     <img src="assets/images/testimonial-icone.png">
                  </div>
                  <p>Choosing this team was the best decision we made. Their legal guidance was clear, professional, and truly effective in our case.</p>
                  <div class="media-body text-center">
                     <h4 class="body-slider media-heading">- Harry , Managing Director at LegalPlus</h4>
                  </div>
               </div>
               <div class="item">
                  <div class="media">
                     <img src="assets/images/testimonial-icone.png">
                  </div>
                  <p>They handled our situation with great care and dedication. Highly recommend their services to anyone looking for honest legal help.</p>
                  <div class="media-body text-center">
                     <h4 class="body-slider media-heading">- Olivia charlie, Founder of charlie Solutions</h4>
                  </div>
               </div>
               <div class="item">
                  <div class="media">
                     <img src="assets/images/testimonial-icone.png">
                  </div>
                  <p>Professional, responsive, and trustworthy — they exceeded our expectations at every step. Thank you for your outstanding support.</p>
                  <div class="media-body text-center">
                     <h4 class="body-slider media-heading">- Mark Chapman, HR Head at Orion Tech</h4>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<!--#End Our testimonial Area -->
 <div class="our_partners_area bg_gradient_team">
   <div class="book_now_aera">
      <div class="container">
         <div class="row book_now">
            <div class="col-md-7 booking_text">
               <h4>Looking for reliable legal guidance or expert consultation?<br> We’re here to support you every step of the way.</h4>
               <p>Start today and discover how we help clients understand their rights, make informed decisions, and achieve the best outcomes.</p>
            </div>
            <div class="col-md-5 p0 book_bottun">
               <div class="col-md-5">
               </div>
               <div class="col-md-7">
                  <div class="top-banner wow fadeInRight text-left"
                     style="visibility: visible; animation-name: fadeInRight;">
                     <a id="#services" href="contact.php"
                        class="btn btn-primary radius-50  wow fadeInUp  js-scroll-trigger" data-wow-delay="0.5s"
                        style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInUp;">Free
                        Consultation</a>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>


   <!--#start Our footer Area -->
       <?php include 'footer.php'; ?>
       
      <!--#End Our footer Area -->

      <!-- jQuery JS -->
      <script src="assets/js/jquery-1.12.0.min.js"></script>
      <!-- Bootstrap JS -->
      <script src="assets/js/bootstrap.min.js"></script>
    
      <!-- Animate JS -->
      <script src="assets/vendors/animate/wow.min.js"></script>
      <!-- Owlcarousel JS -->
      <script src="assets/vendors/owl_carousel/owl.carousel.min.js"></script>
      <!-- Stellar JS -->
      <!-- Theme JS -->
      <script src="assets/js/theme.min.js"></script>
   </body>
</html>