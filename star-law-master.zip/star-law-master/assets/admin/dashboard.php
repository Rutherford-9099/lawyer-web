<?php
if (session_id() == '') {
    session_start();
}
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include 'conn.php';

// Approve lawyer profile
if (isset($_GET['approve'])) {
    $id = (int) $_GET['approve'];
    $stmt = $conn->prepare("UPDATE lawyers SET is_approved = 1 WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    header("Location: dashboard.php");
    exit();
}

// Decline lawyer profile
if (isset($_GET['decline'])) {
    $id = (int) $_GET['decline'];
    $stmt = $conn->prepare("UPDATE lawyers SET is_approved = -1 WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    header("Location: dashboard.php");
    exit();
}

// Fetch counts for dashboard summary
$totalLawyers = $conn->query("SELECT COUNT(*) AS total FROM lawyers")->fetch_assoc()['total'];
$totalUsers = $conn->query("SELECT COUNT(*) AS total FROM users")->fetch_assoc()['total'];
$totalAppointments = $conn->query("SELECT COUNT(*) AS total FROM appointments")->fetch_assoc()['total'];

// Fetch pending lawyers for approval
$result = $conn->query("SELECT * FROM lawyers WHERE is_approved = 0");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Admin Dashboard - Lawyer Approvals</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
<style>
  /* Reset */
  
  * {
    box-sizing: border-box;
  }

  body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    margin: 0;
    background-color: #f0f2f5;
    color: #333;
  }

  header {
    background-color: #004085;
    color: #fff;
    padding: 15px 30px;
    font-size: 1.5rem;
    font-weight: 700;
    letter-spacing: 1px;
  }

  .container {
    max-width: 1000px;
    margin: 30px auto;
    background: #fff;
    border-radius: 12px;
    padding: 30px;
    box-shadow: 0 4px 12px rgb(0 0 0 / 0.1);
  }

  h2 {
    margin-bottom: 25px;
    color: #004085;
    text-align: center;
  }

  .card {
    background: #fafafa;
    border-radius: 10px;
    padding: 20px 25px;
    margin-bottom: 20px;
    border-left: 5px solid #007bff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    transition: box-shadow 0.3s ease;
  }
  .card:hover {
    box-shadow: 0 6px 20px rgb(0 123 255 / 0.3);
  }

  .info-group {
    display: flex;
    flex-direction: column;
    gap: 6px;
    max-width: 70%;
  }
  .lawyer-name {
    font-size: 1.2rem;
    font-weight: 700;
    color: #007bff;
  }
  .lawyer-info {
    font-size: 0.95rem;
    color: #555;
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .actions {
    display: flex;
    gap: 12px;
  }
  .btn {
    cursor: pointer;
    padding: 8px 16px;
    border-radius: 6px;
    font-weight: 600;
    text-decoration: none;
    user-select: none;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    border: none;
    font-size: 0.95rem;
    transition: background-color 0.3s ease;
  }
  .btn-approve {
    background-color: #28a745;
    color: white;
  }
  .btn-approve:hover {
    background-color: #218838;
  }
  .btn-decline {
    background-color: #dc3545;
    color: white;
  }
  .btn-decline:hover {
    background-color: #c82333;
  }

  .no-results {
    text-align: center;
    color: #777;
    font-style: italic;
    font-size: 1rem;
    padding: 50px 0;
  }

  @media (max-width: 600px) {
    .card {
      flex-direction: column;
      align-items: flex-start;
      gap: 15px;
    }
    .info-group {
      max-width: 100%;
    }
    .actions {
      width: 100%;
      justify-content: flex-start;
    }
  }

  /* Dashboard summary cards styles */
  .dashboard-summary {
    display: flex;
    gap: 20px;
    justify-content: space-between;
    margin-bottom: 40px;
  }
  .dashboard-summary .card {
    flex: 1;
    border-left-width: 5px !important;
  }
  .dashboard-summary .card:nth-child(1) { border-left-color: #007bff; }
  .dashboard-summary .card:nth-child(2) { border-left-color: #28a745; }
  .dashboard-summary .card:nth-child(3) { border-left-color: #ffc107; }
  .dashboard-summary p {
    font-size: 1.5rem;
    font-weight: 700;
    margin: 0;
  }
  .dashboard-summary h4 {
    margin-bottom: 10px;
  }
</style>
</head>
<body>

<?php include 'navbar.php'; ?>



<div style="max-width:1000px; margin: 20px auto; display: flex; gap: 15px;">
  <a href="manage_lawyers.php" style="text-decoration:none; padding:10px 15px; background:#007bff; color:#fff; border-radius:5px;">Manage Lawyers</a>
  <a href="manage_customers.php" style="text-decoration:none; padding:10px 15px; background:#28a745; color:#fff; border-radius:5px;">Manage Customers</a>
  <a href="manage_appointments.php" style="text-decoration:none; padding:10px 15px; background:#ffc107; color:#333; border-radius:5px;">Manage Appointments</a>
  <a href="manage_homepage.php" style="text-decoration:none; padding:10px 15px; background:#6f42c1; color:#fff; border-radius:5px;">Manage Homepage</a>
</div>

<div class="container">
  <div class="dashboard-summary">
    <div class="card">
      <h4>Total Lawyers</h4>
      <p><?= $totalLawyers ?></p>
    </div>
    <div class="card">
      <h4>Total Customers</h4>
      <p><?= $totalUsers ?></p>
    </div>
    <div class="card">
      <h4>Total Appointments</h4>
      <p><?= $totalAppointments ?></p>
    </div>
  </div>

  <h2>Pending Lawyer Profiles for Approval</h2>

  <?php if ($result && $result->num_rows > 0): ?>
    <?php while ($row = $result->fetch_assoc()): ?>
      <div class="card">
        <div class="info-group">
          <div class="lawyer-name"><i class="fas fa-user"></i> <?= htmlspecialchars($row['name']) ?></div>
          <div class="lawyer-info"><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($row['location']) ?></div>
          <div class="lawyer-info"><i class="fas fa-balance-scale"></i> <?= htmlspecialchars($row['case_type']) ?></div>
        </div>
        <div class="actions">
          <a class="btn btn-approve" href="?approve=<?= $row['id'] ?>" title="Approve Profile">
            <i class="fas fa-check-circle"></i> Approve
          </a>
          <a class="btn btn-decline" href="?decline=<?= $row['id'] ?>" onclick="return confirm('Are you sure you want to decline this profile?');" title="Decline Profile">
            <i class="fas fa-times-circle"></i> Decline
          </a>
        </div>
      </div>
    <?php endwhile; ?>
  <?php else: ?>
    <p class="no-results">No pending profiles to approve.</p>
  <?php endif; ?>
</div>

</body>
</html>

<?php
$conn->close();
?>
