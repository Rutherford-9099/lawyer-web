<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include 'conn.php';

// Delete lawyer
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM lawyers WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    header("Location: manage_lawyers.php");
    exit();
}

// Fetch all lawyers
$result = $conn->query("SELECT * FROM lawyers ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Manage Lawyers</title>
<style>
  body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    margin: 0;
    padding: 0;
    background: #f9f9f9;
    color: #333;
  }

  div.container {
    max-width: 1100px;
    margin: 30px auto;
    padding: 20px;
    background: white;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    border-radius: 8px;
  }

  h2 {
    margin-bottom: 20px;
    font-weight: 700;
    color: #222;
    letter-spacing: 0.03em;
  }

  table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0 15px; /* vertical spacing between rows */
    font-size: 15px;
  }

  thead tr th {
    background-color: #ffc107;
    color: #222;
    font-weight: 600;
    padding: 12px 15px;
    border-radius: 8px 8px 0 0;
    text-align: left;
    border-bottom: 3px solid #e0a800; /* strong bottom border */
  }

  tbody tr {
    background-color: #fff;
    box-shadow: 0 1px 6px rgba(0,0,0,0.08);
    transition: background-color 0.3s ease;
    border-radius: 8px; /* rounded corners on entire row */
    display: table-row; /* ensure proper display */
  }

  tbody tr:hover {
    background-color: #f1f1f1;
  }

  tbody td {
    padding: 14px 15px;
    vertical-align: middle;
    border-left: 1px solid #eee;
    border-right: 1px solid #eee;
    border-bottom: none; /* remove bottom border to avoid double line */
  }

  tbody tr:last-child td {
    border-radius: 0 0 8px 8px;
  }

  a.btn {
    padding: 8px 16px;
    border-radius: 5px;
    text-decoration: none;
    color: white;
    font-weight: 600;
    font-size: 14px;
    margin-right: 6px;
    display: inline-block;
    transition: background-color 0.25s ease;
    box-shadow: 0 2px 6px rgba(0,0,0,0.15);
  }

  .btn-edit {
    background-color: #007bff;
  }

  .btn-edit:hover {
    background-color: #0056b3;
  }

  .btn-delete {
    background-color: #6c757d;
  }

  .btn-delete:hover {
    background-color: #4e555b;
  }

  /* Responsive */
  @media (max-width: 700px) {
    table, thead, tbody, th, td, tr {
      display: block;
    }
    thead tr {
      display: none;
    }
    tbody tr {
      margin-bottom: 15px;
      box-shadow: none;
      background-color: transparent;
      border-radius: 0;
    }
    tbody td {
      padding-left: 50%;
      text-align: right;
      border: none;
      position: relative;
    }
    tbody td::before {
      content: attr(data-label);
      position: absolute;
      left: 15px;
      width: 45%;
      padding-left: 10px;
      font-weight: 600;
      text-align: left;
      color: #666;
    }
  }
</style>
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="container">
  <h2>Manage Lawyers</h2>
  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Location</th>
        <th>Case Type</th>
        <th>Approved</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php if ($result && $result->num_rows > 0): ?>
        <?php while ($row = $result->fetch_assoc()): ?>
          <tr>
            <td data-label="ID"><?= $row['id'] ?></td>
            <td data-label="Name"><?= htmlspecialchars($row['name']) ?></td>
            <td data-label="Location"><?= htmlspecialchars($row['location']) ?></td>
            <td data-label="Case Type"><?= htmlspecialchars($row['case_type']) ?></td>
            <td data-label="Approved">
              <?php 
                if ($row['is_approved'] == 1) echo "Yes"; 
                elseif ($row['is_approved'] == 0) echo "Pending"; 
                else echo "Declined"; 
              ?>
            </td>
            <td data-label="Actions">
              <a class="btn btn-edit" href="edit_lawyer.php?id=<?= $row['id'] ?>">Edit</a>
              <a class="btn btn-delete" href="?delete=<?= $row['id'] ?>" onclick="return confirm('Delete this lawyer?');">Delete</a>
            </td>
          </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr><td colspan="6" style="text-align:center;">No lawyers found.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

</body>
</html>

<?php $conn->close(); ?>
