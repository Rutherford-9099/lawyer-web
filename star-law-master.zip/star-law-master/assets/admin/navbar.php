<style>
  .navbar {
    background-color: #004085;
    padding: 10px 25px;
    display: flex;
    align-items: center;
    gap: 20px;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    flex-wrap: wrap;
    border-radius: 0 0 10px 10px; /* slight curve */
    box-shadow: 0 4px 12px rgba(0, 64, 133, 0.3);
  }

  .navbar .brand {
    font-weight: 700;
    font-size: 1.3rem;
    color: #ffc107;
    margin-right: auto;
    letter-spacing: 1px;
  }

  /* Dashboard */
  .navbar a.active {
    background-color: #ffc107;
    color: #004085;
    font-weight: 700;
    padding: 8px 16px;
    border-radius: 5px;
    box-shadow: 0 2px 8px rgba(255, 193, 7, 0.6);
    text-decoration: none;
  }

  /* Management links */
  .navbar a:not(.active):not(.logout) {
    position: relative;
    color: #ffffffcc;
    font-weight: 600;
    padding: 8px 16px;
    text-decoration: none;
    border-radius: 5px;
    transition: color 0.3s ease, background-color 0.3s ease;
  }

  .navbar a:not(.active):not(.logout):hover {
    background-color: rgba(255, 255, 255, 0.1);
    color: #fff;
  }

  .navbar a:not(.active):not(.logout)::after {
    content: "";
    position: absolute;
    width: 0%;
    height: 2px;
    bottom: 4px;
    left: 0;
    background-color: #ffc107;
    transition: width 0.3s ease;
    border-radius: 2px;
  }

  .navbar a:not(.active):not(.logout):hover::after {
    width: 100%;
  }

  /* Logout */
  .navbar a.logout {
    margin-left: auto;
    background-color: #dc3545;
    font-weight: 700;
    color: #fff;
    padding: 8px 16px;
    border-radius: 5px;
    transition: background-color 0.3s ease, box-shadow 0.3s ease;
    text-decoration: none;
  }

  .navbar a.logout:hover {
    background-color: #a71d2a;
    box-shadow: 0 2px 8px rgba(215, 35, 48, 0.6);
  }

  /* Responsive */
  @media (max-width: 600px) {
    .navbar {
      justify-content: center;
      gap: 10px;
    }

    .navbar .brand {
      flex-basis: 100%;
      text-align: center;
      margin-bottom: 10px;
    }

    .navbar a.logout {
      margin-left: 0;
    }
  }
</style>

<div class="navbar">
  <div class="brand">Admin Panel</div>
  <a href="dashboard.php" class="active">Dashboard</a>
  <a href="manage_lawyers.php">Manage Lawyers</a>
  <a href="manage_customers.php">Manage Customers</a>
  <a href="manage_appointments.php">Manage Appointments</a>
  <a href="manage_contacts.php">Contact Messages</a>
  <a href="../index.php" class="logout">Logout</a>
</div>
