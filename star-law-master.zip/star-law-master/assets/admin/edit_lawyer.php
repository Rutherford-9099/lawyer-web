<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include 'conn.php';

if (!isset($_GET['id'])) {
    header("Location: manage_lawyers.php");
    exit();
}

$id = (int)$_GET['id'];

// Update lawyer on POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'] ?? '';
    $location = $_POST['location'] ?? '';
    $case_type = $_POST['case_type'] ?? '';
    $is_approved = isset($_POST['is_approved']) ? (int)$_POST['is_approved'] : 0;

    $stmt = $conn->prepare("UPDATE lawyers SET name=?, location=?, case_type=?, is_approved=? WHERE id=?");
    $stmt->bind_param("sssii", $name, $location, $case_type, $is_approved, $id);
    $stmt->execute();
    $stmt->close();

    header("Location: manage_lawyers.php");
    exit();
}

// Fetch current lawyer data
$stmt = $conn->prepare("SELECT * FROM lawyers WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 0) {
    header("Location: manage_lawyers.php");
    exit();
}
$lawyer = $result->fetch_assoc();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Edit Lawyer</title>
<style>
  body {
    font-family: Arial, sans-serif;
    padding: 25px;
    max-width: 500px;
    margin: 40px auto;
    background: #f9f9f9;
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
  }

  h2 {
    text-align: center;
    margin-bottom: 30px;
    color: #222;
  }

  form {
    display: flex;
    flex-direction: column;
    gap: 18px;
  }

  label {
    font-weight: 600;
    color: #444;
  }

  input[type="text"],
  select {
    padding: 10px 12px;
    font-size: 1rem;
    border: 1.5px solid #ccc;
    border-radius: 6px;
    transition: border-color 0.3s ease;
  }

  input[type="text"]:focus,
  select:focus {
    border-color: #007bff;
    outline: none;
  }

  button {
    padding: 12px;
    background-color: #007bff;
    border: none;
    border-radius: 6px;
    color: white;
    font-weight: 700;
    font-size: 1.1rem;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }

  button:hover,
  button:focus {
    background-color: #0056b3;
    outline: none;
  }
</style>
</head>
<body>

<h2>Edit Lawyer</h2>

<form method="post">
  <label for="name">Name:</label>
  <input id="name" type="text" name="name" value="<?= htmlspecialchars($lawyer['name']) ?>" required />
  
  <label for="location">Location:</label>
  <input id="location" type="text" name="location" value="<?= htmlspecialchars($lawyer['location']) ?>" required />
  
  <label for="case_type">Case Type:</label>
  <input id="case_type" type="text" name="case_type" value="<?= htmlspecialchars($lawyer['case_type']) ?>" required />

  <label for="is_approved">Approval Status:</label>
  <select id="is_approved" name="is_approved">
    <option value="0" <?= $lawyer['is_approved'] == 0 ? 'selected' : '' ?>>Pending</option>
    <option value="1" <?= $lawyer['is_approved'] == 1 ? 'selected' : '' ?>>Approved</option>
    <option value="-1" <?= $lawyer['is_approved'] == -1 ? 'selected' : '' ?>>Declined</option>
  </select>
  
  <button type="submit">Update Lawyer</button>
</form>

</body>
</html>
