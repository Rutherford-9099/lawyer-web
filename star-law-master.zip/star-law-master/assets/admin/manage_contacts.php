<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include 'conn.php';

// Delete contact
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM contact WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    header("Location: manage_contacts.php");
    exit();
}

// Fetch all contact messages
$result = $conn->query("SELECT * FROM contact ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Manage Contact Messages</title>
<style>
  body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    margin: 0;
    background: #f5f7fa;
    color: #333;
  }

  .container {
    max-width: 1100px;
    margin: 30px auto;
    padding: 20px 30px;
    background: white;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  }

  h2 {
    margin-bottom: 25px;
    font-weight: 700;
    color: #222;
    letter-spacing: 0.03em;
  }

  table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0 15px;
    font-size: 15px;
  }

  thead tr th {
    background-color: #ffc107;
    color: #222;
    font-weight: 600;
    padding: 12px 15px;
    border-radius: 8px 8px 0 0;
    text-align: left;
    border-bottom: 3px solid #e0a800;
  }

  tbody tr {
    background-color: #fff;
    box-shadow: 0 1px 6px rgba(0,0,0,0.08);
    transition: background-color 0.3s ease;
    border-radius: 8px;
  }

  tbody tr:hover {
    background-color: #f1f1f1;
  }

  tbody td {
    padding: 14px 15px;
    vertical-align: middle;
    border-left: 1px solid #eee;
    border-right: 1px solid #eee;
  }

  a.btn {
    padding: 8px 16px;
    border-radius: 5px;
    text-decoration: none;
    color: white;
    font-weight: 600;
    font-size: 14px;
    margin-right: 6px;
    display: inline-block;
    transition: background-color 0.25s ease;
    box-shadow: 0 2px 6px rgba(0,0,0,0.15);
  }

  a.btn-delete {
    background-color: #6c757d;
  }

  a.btn-delete:hover {
    background-color: #4e555b;
  }

  @media (max-width: 700px) {
    table, thead, tbody, th, td, tr {
      display: block;
    }
    thead tr {
      display: none;
    }
    tbody tr {
      margin-bottom: 15px;
      box-shadow: none;
      background-color: transparent;
    }
    tbody td {
      padding-left: 50%;
      text-align: right;
      border: none;
      position: relative;
    }
    tbody td::before {
      content: attr(data-label);
      position: absolute;
      left: 15px;
      width: 45%;
      font-weight: 600;
      text-align: left;
      color: #666;
    }
  }
</style>
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="container">
  <h2>Contact Messages</h2>
  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Subject</th>
        <th>Message</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php if ($result && $result->num_rows > 0): ?>
        <?php while ($row = $result->fetch_assoc()): ?>
          <tr>
            <td data-label="ID"><?= $row['id'] ?></td>
            <td data-label="Name"><?= htmlspecialchars($row['name']) ?></td>
            <td data-label="Email"><?= htmlspecialchars($row['email']) ?></td>
            <td data-label="Subject"><?= htmlspecialchars($row['subject']) ?></td>
            <td data-label="Message"><?= nl2br(htmlspecialchars($row['message'])) ?></td>
            <td data-label="Actions">
              <a class="btn btn-delete" href="?delete=<?= $row['id'] ?>" onclick="return confirm('Delete this message?');">Delete</a>
            </td>
          </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr><td colspan="6" style="text-align:center;">No contact messages found.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

</body>
</html>

<?php $conn->close(); ?>
