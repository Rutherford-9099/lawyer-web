<?php
session_start();
include 'conn.php';

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM admin WHERE username=? AND password=?");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $_SESSION['admin'] = $username;
        header("Location: dashboard.php");
        exit();
    } else {
        $error = "Invalid username or password";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Admin Login</title>
<style>
  /* Base Reset & Fonts */
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');

  body {
    font-family: 'Inter', sans-serif;
    margin: 0;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #333;
    position: relative;
    overflow: hidden;
  }

  .bg-image {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-image: url('img/admin login img.png');
    background-size: cover;
    background-position: center;
    filter: brightness(0.6);
    z-index: -1;
  }

 .login-container {
  background: rgba(255, 255, 255, 0.85); /* thoda transparent white */
  padding: 40px 50px;
  width: 380px;
  border-radius: 12px;
  box-shadow:
    0 4px 15px rgba(0, 0, 0, 0.1),  /* halki shadow */
    0 1px 4px rgba(0, 0, 0, 0.05);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  z-index: 1;
}

.login-container:hover {
  transform: translateY(-6px);
  box-shadow:
    0 8px 25px rgba(0, 0, 0, 0.15),
    0 2px 8px rgba(0, 0, 0, 0.08);
}


  h2 {
    margin-bottom: 30px;
    font-weight: 700;
    color: #222;
    text-align: center;
    letter-spacing: 0.05em;
  }

  .error-msg {
    background: #ffebeb;
    border: 1.5px solid #ff5c5c;
    color: #a70000;
    padding: 12px 15px;
    margin-bottom: 20px;
    border-radius: 6px;
    text-align: center;
    font-weight: 600;
    letter-spacing: 0.02em;
    box-shadow: 0 2px 6px rgba(255, 92, 92, 0.3);
  }

  label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: #555;
  }

  input[type="text"],
  input[type="password"] {
    width: 100%;
    padding: 14px 18px;
    margin-bottom: 25px;
    border: 1.8px solid #ddd;
    border-radius: 8px;
    font-size: 16px;
    color: #222;
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
    box-sizing: border-box;
  }

  input[type="text"]:focus,
  input[type="password"]:focus {
    border-color: #4a90e2;
    box-shadow: 0 0 8px rgba(74, 144, 226, 0.6);
    outline: none;
  }

  button {
    width: 100%;
    padding: 15px;
    background-color: #4a90e2;
    border: none;
    border-radius: 8px;
    color: white;
    font-weight: 700;
    font-size: 18px;
    cursor: pointer;
    box-shadow: 0 4px 12px rgba(74, 144, 226, 0.6);
    transition: background-color 0.3s ease, box-shadow 0.3s ease;
    letter-spacing: 0.05em;
  }

  button:hover {
    background-color: #357abd;
    box-shadow: 0 6px 20px rgba(53, 122, 189, 0.8);
  }

  @media (max-width: 420px) {
    .login-container {
      width: 90%;
      padding: 30px 20px;
    }
  }
</style>
</head>
<body>

<div class="bg-image"></div>

<div class="login-container">
  <h2>Admin Login</h2>
  <?php if ($error): ?>
    <div class="error-msg"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>
  <form method="POST" action="">
    <label for="username">Username</label>
    <input id="username" name="username" type="text" placeholder="Enter username" required />

    <label for="password">Password</label>
    <input id="password" name="password" type="password" placeholder="Enter password" required />

    <button type="submit">Sign In</button>
  </form>
</div>

</body>
</html>
