<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include 'conn.php';

if (!isset($_GET['id'])) {
    header("Location: manage_appointments.php");
    exit();
}

$id = (int)$_GET['id'];

// Update appointment on POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $date = $_POST['appointment_date'] ?? '';
    $time = $_POST['appointment_time'] ?? '';
    $status = $_POST['status'] ?? 'Pending';

    $stmt = $conn->prepare("UPDATE appointments SET appointment_date=?, appointment_time=?, status=? WHERE id=?");
    $stmt->bind_param("sssi", $date, $time, $status, $id);
    $stmt->execute();
    $stmt->close();

    header("Location: manage_appointments.php");
    exit();
}

// Fetch current appointment data
$stmt = $conn->prepare("SELECT * FROM appointments WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    header("Location: manage_appointments.php");
    exit();
}
$appointment = $result->fetch_assoc();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Edit Appointment</title>
<style>
  body {
    font-family: Arial, sans-serif;
    max-width: 600px;
    margin: 40px auto;
    padding: 25px;
    background: #f8f9fa;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    border-radius: 8px;
  }

  h2 {
    text-align: center;
    margin-bottom: 30px;
    color: #343a40;
  }

  form {
    display: flex;
    flex-direction: column;
    gap: 20px;
  }

  label {
    font-weight: 600;
    color: #495057;
  }

  input[type="date"],
  input[type="time"],
  select {
    padding: 10px 12px;
    font-size: 1rem;
    border: 1.8px solid #ced4da;
    border-radius: 6px;
    transition: border-color 0.3s ease;
  }

  input[type="date"]:focus,
  input[type="time"]:focus,
  select:focus {
    border-color: #007bff;
    outline: none;
  }

  button {
    padding: 12px;
    background-color: #007bff;
    border: none;
    border-radius: 6px;
    color: #fff;
    font-weight: 600;
    font-size: 1.1rem;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }

  button:hover,
  button:focus {
    background-color: #0056b3;
    outline: none;
  }
</style>
</head>
<body>

<h2>Edit Appointment</h2>

<form method="post">
  <label for="appointment_date">Appointment Date:</label>
  <input id="appointment_date" type="date" name="appointment_date" value="<?= htmlspecialchars($appointment['appointment_date']) ?>" required />

  <label for="appointment_time">Appointment Time:</label>
  <input id="appointment_time" type="time" name="appointment_time" value="<?= htmlspecialchars($appointment['appointment_time']) ?>" required />

  <label for="status">Status:</label>
  <select id="status" name="status" required>
    <option value="Pending" <?= $appointment['status'] == 'Pending' ? 'selected' : '' ?>>Pending</option>
    <option value="Confirmed" <?= $appointment['status'] == 'Confirmed' ? 'selected' : '' ?>>Confirmed</option>
    <option value="Declined" <?= $appointment['status'] == 'Declined' ? 'selected' : '' ?>>Declined</option>
  </select>

  <button type="submit">Update Appointment</button>
</form>

</body>
</html>
