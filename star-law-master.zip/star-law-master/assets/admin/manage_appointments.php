<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include 'conn.php';

// Approve appointment
if (isset($_GET['approve'])) {
    $id = (int)$_GET['approve'];
    $stmt = $conn->prepare("UPDATE appointments SET status = 'Approved' WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    header("Location: manage_appointments.php");
    exit();
}

// Delete appointment
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM appointments WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    header("Location: manage_appointments.php");
    exit();
}

// Query appointments
$query = "SELECT 
    a.id,
    CONCAT(a.first_name, ' ', a.last_name) AS user_name,
    l.name AS lawyer_name,
    a.service_type,
    a.urgency,
    a.budget,
    a.status
FROM appointments a
LEFT JOIN lawyers l ON a.lawyer_id = l.id
LEFT JOIN users u ON a.user_id = u.id
ORDER BY a.id DESC";

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Manage Appointments</title>
<style>
  /* same styling as before */
  body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    margin: 0;
    background: #f5f7fa;
    color: #333;
  }
  .container {
    max-width: 1100px;
    margin: 30px auto;
    padding: 20px 30px;
    background: white;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  }
  h2 {
    margin-bottom: 25px;
    font-weight: 700;
    color: #222;
    letter-spacing: 0.03em;
  }
  table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0 15px;
    font-size: 15px;
  }
  thead tr th {
    background-color: #ffc107;
    color: #222;
    font-weight: 600;
    padding: 12px 15px;
    border-radius: 8px 8px 0 0;
    text-align: left;
    border-bottom: 3px solid #e0a800;
  }
  tbody tr {
    background-color: #fff;
    box-shadow: 0 1px 6px rgba(0,0,0,0.08);
    transition: background-color 0.3s ease;
    border-radius: 8px;
    display: table-row;
  }
  tbody tr:hover {
    background-color: #f1f1f1;
  }
  tbody td {
    padding: 14px 15px;
    vertical-align: middle;
    border-left: 1px solid #eee;
    border-right: 1px solid #eee;
  }
  tbody tr:last-child td {
    border-radius: 0 0 8px 8px;
  }
  a.btn {
    padding: 8px 16px;
    border-radius: 5px;
    text-decoration: none;
    color: white;
    font-weight: 600;
    font-size: 14px;
    margin-right: 6px;
    display: inline-block;
    transition: background-color 0.25s ease;
    box-shadow: 0 2px 6px rgba(0,0,0,0.15);
  }
  a.btn-edit {
    background-color: #007bff;
  }
  a.btn-edit:hover {
    background-color: #0056b3;
  }
  a.btn-delete {
    background-color: #6c757d;
  }
  a.btn-delete:hover {
    background-color: #4e555b;
  }
  a.btn-approve {
    background-color: #28a745;
  }
  a.btn-approve:hover {
    background-color: #1e7e34;
  }
  @media (max-width: 700px) {
    table, thead, tbody, th, td, tr {
      display: block;
    }
    thead tr {
      display: none;
    }
    tbody tr {
      margin-bottom: 15px;
      box-shadow: none;
      background-color: transparent;
      border-radius: 0;
    }
    tbody td {
      padding-left: 50%;
      text-align: right;
      border: none;
      position: relative;
    }
    tbody td::before {
      content: attr(data-label);
      position: absolute;
      left: 15px;
      width: 45%;
      padding-left: 10px;
      font-weight: 600;
      text-align: left;
      color: #666;
    }
  }
</style>
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="container">
  <h2>Manage Appointments</h2>
  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>User</th>
        <th>Lawyer</th>
        <th>Service</th>
        <th>Urgency</th>
        <th>Budget</th>
        <th>Status</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php if ($result && $result->num_rows > 0): ?>
        <?php while ($row = $result->fetch_assoc()): ?>
          <tr>
            <td data-label="ID"><?= $row['id'] ?></td>
            <td data-label="User"><?= htmlspecialchars($row['user_name']) ?></td>
            <td data-label="Lawyer"><?= htmlspecialchars($row['lawyer_name'] ?? 'N/A') ?></td>
            <td data-label="Service"><?= htmlspecialchars($row['service_type']) ?></td>
            <td data-label="Urgency"><?= htmlspecialchars($row['urgency']) ?></td>
            <td data-label="Budget"><?= htmlspecialchars($row['budget']) ?></td>
            <td data-label="Status"><?= htmlspecialchars($row['status']) ?></td>
            <td data-label="Actions">
              <a class="btn btn-edit" href="edit_appointment.php?id=<?= $row['id'] ?>">Edit</a>
              <a class="btn btn-delete" href="?delete=<?= $row['id'] ?>" onclick="return confirm('Delete this appointment?');">Delete</a>
              <?php if (strtolower($row['status']) !== 'approved'): ?>
                <a class="btn btn-approve" href="?approve=<?= $row['id'] ?>" onclick="return confirm('Approve this appointment?');">Approve</a>
              <?php endif; ?>
            </td>
          </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr><td colspan="8" style="text-align:center;">No appointments found.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

</body>
</html>

<?php $conn->close(); ?>
