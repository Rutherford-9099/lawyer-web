<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include 'conn.php';

if (!isset($_GET['id'])) {
    header("Location: manage_customers.php");
    exit();
}

$id = (int)$_GET['id'];

// Update customer on POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    $stmt = $conn->prepare("UPDATE users SET name=?, email=?, password=? WHERE id=?");
    $stmt->bind_param("sssi", $name, $email, $password, $id);
    $stmt->execute();
    $stmt->close();

    header("Location: manage_customers.php");
    exit();
}

// Fetch current customer data
$stmt = $conn->prepare("SELECT * FROM users WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 0) {
    header("Location: manage_customers.php");
    exit();
}
$customer = $result->fetch_assoc();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Edit Customer</title>
<style>
  body {
    font-family: Arial, sans-serif;
    padding: 20px;
    max-width: 600px;
    margin: 40px auto;
    background: #f9f9f9;
  }

  h2 {
    text-align: center;
    margin-bottom: 25px;
    color: #333;
  }

  form {
    background: white;
    padding: 25px 30px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    display: flex;
    flex-direction: column;
    gap: 18px;
  }

  label {
    font-weight: bold;
    color: #555;
  }

  input[type="text"],
  input[type="email"],
  input[type="password"] {
    padding: 10px;
    font-size: 1rem;
    border: 1.8px solid #ccc;
    border-radius: 5px;
    transition: border-color 0.3s ease;
  }

  input[type="text"]:focus,
  input[type="email"]:focus,
  input[type="password"]:focus {
    border-color: #007bff;
    outline: none;
  }

  button {
    padding: 12px;
    background: #007bff;
    color: white;
    border: none;
    cursor: pointer;
    border-radius: 6px;
    font-size: 1.1rem;
    font-weight: 600;
    transition: background-color 0.3s ease;
  }

  button:hover,
  button:focus {
    background-color: #0056b3;
    outline: none;
  }
</style>
</head>
<body>

<h2>Edit Customer</h2>

<form method="post" autocomplete="off">
  <label for="name">Name:</label>
  <input id="name" type="text" name="name" value="<?= htmlspecialchars($customer['name']) ?>" required />
  
  <label for="email">Email:</label>
  <input id="email" type="email" name="email" value="<?= htmlspecialchars($customer['email']) ?>" required />
  
  <label for="password">Password:</label>
  <input id="password" type="password" name="password" value="<?= htmlspecialchars($customer['password']) ?>" required />
  
  <button type="submit">Update Customer</button>
</form>

</body>
</html>
