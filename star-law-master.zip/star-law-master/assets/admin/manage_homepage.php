<?php
if (session_id() == '') {
    session_start();
}
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include 'conn.php';

// Add new attorney
if (isset($_POST['add_attorney'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $specialization = $conn->real_escape_string($_POST['specialization']);
    
    // Photo upload
    $photoName = '';
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] == 0) {
        $photoName = basename($_FILES['photo']['name']);
        $targetPath = "img/" . $photoName;
        move_uploaded_file($_FILES['photo']['tmp_name'], $targetPath);
    }
    
    $stmt = $conn->prepare("INSERT INTO homepage_attorneys (name, specialization, photo) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $specialization, $photoName);
    $stmt->execute();
    $stmt->close();
}

// Edit attorney functionality
if (isset($_POST['edit_attorney'])) {
    $id = (int)$_POST['id'];
    $name = $conn->real_escape_string($_POST['name']);
    $specialization = $conn->real_escape_string($_POST['specialization']);
    
    // Handle photo update if new file uploaded
    if(!empty($_FILES['photo']['name'])) {
        // Delete old photo
        $result = $conn->query("SELECT photo FROM homepage_attorneys WHERE id = $id");
        if($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $oldPhoto = "img/".$row['photo'];
            if(file_exists($oldPhoto)) {
                unlink($oldPhoto);
            }
        }
        
        // Upload new photo
        $photoName = basename($_FILES['photo']['name']);
        $targetPath = "img/" . $photoName;
        move_uploaded_file($_FILES['photo']['tmp_name'], $targetPath);
        
        $stmt = $conn->prepare("UPDATE homepage_attorneys SET name=?, specialization=?, photo=? WHERE id=?");
        $stmt->bind_param("sssi", $name, $specialization, $photoName, $id);
    } else {
        $stmt = $conn->prepare("UPDATE homepage_attorneys SET name=?, specialization=? WHERE id=?");
        $stmt->bind_param("ssi", $name, $specialization, $id);
    }
    
    $stmt->execute();
    $stmt->close();
    header("Location: manage_homepage.php");
    exit();
}

// Delete attorney
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    
    // First get photo name
    $result = $conn->query("SELECT photo FROM homepage_attorneys WHERE id = $id");
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $photoPath = "img/" . $row['photo'];
        if (file_exists($photoPath)) {
            unlink($photoPath);
        }
    }
    
    $conn->query("DELETE FROM homepage_attorneys WHERE id = $id");
    header("Location: manage_homepage.php");
    exit();
}

// Fetch all attorneys for homepage
$attorneys = $conn->query("SELECT * FROM homepage_attorneys ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Homepage Attorneys</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
  body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    margin: 0;
    background-color: #f0f2f5;
    color: #333;
  }
  
  .container {
    max-width: 1200px;
    margin: 30px auto;
    padding: 20px;
  }
  
  h2 {
    color: #004085;
    text-align: center;
    margin-bottom: 30px;
  }
  
  .form-container {
    background: #fff;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    margin-bottom: 30px;
  }
  
  .form-group {
    margin-bottom: 20px;
  }
  
  .form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
  }
  
  .form-group input, .form-group select, .form-group textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 16px;
  }
  
  .btn {
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-weight: 600;
    transition: background-color 0.3s;
  }
  
  .btn-primary {
    background-color: #007bff;
    color: white;
  }
  
  .btn-primary:hover {
    background-color: #0056b3;
  }
  
  /* Table Styles */
  .table-responsive {
    overflow-x: auto;
    margin-top: 20px;
  }
  
  .attorney-table {
    width: 100%;
    border-collapse: collapse;
    background: #fff;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
  }
  
  .attorney-table th, 
  .attorney-table td {
    padding: 12px 15px;
    text-align: left;
    border-bottom: 1px solid #f0f0f0;
  }
  
  .attorney-table th {
    background-color: #f8f9fa;
    font-weight: 600;
    color: #333;
  }
  
  .attorney-table tr:hover {
    background-color: #f8f9fa;
  }
  
  .attorney-thumbnail {
    width: 60px;
    height: 60px;
    object-fit: cover;
    border-radius: 4px;
  }
  
  .action-buttons {
    display: flex;
    gap: 10px;
  }
  
  .btn-edit, 
  .btn-delete {
    padding: 6px 12px;
    border-radius: 4px;
    font-size: 14px;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    transition: all 0.2s;
  }
  
  .btn-edit {
    background-color: #4e73df;
    color: white;
    border: none;
    cursor: pointer;
  }
  
  .btn-edit:hover {
    background-color: #3a5ec0;
  }
  
  .btn-delete {
    background-color: #e74a3b;
    color: white;
  }
  
  .btn-delete:hover {
    background-color: #d52a1a;
  }
  
  .no-attorneys {
    text-align: center;
    padding: 30px;
    background: #f8f9fa;
    border-radius: 4px;
    margin-top: 20px;
    color: #6c757d;
  }
  
   /* Updated Modal Styles */
  .modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.5);
    overflow-y: auto; /* Enable scrolling if needed */
  }
  
  .modal-content {
    background-color: #fff;
    margin: 20px auto; /* Changed from 10% to fixed pixels */
    padding: 10px;
    border-radius: 8px;
    width: 90%;
    max-width: 500px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.3);
    position: relative;
    top: 50px; /* Push down from top */
    transform: none; /* Remove any transform */
    max-height: calc(100vh - 100px); /* Limit height */
    overflow-y: auto; /* Make content scrollable */
  }
  
  
  .close {
    position: absolute;
    top: 15px;
    right: 20px;
    font-size: 28px;
    font-weight: bold;
    color: #aaa;
    cursor: pointer;
  }
  
  .close:hover {
    color: #333;
  }
  
  .modal h3 {
    margin-top: 0;
    color: #004085;
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
  }
  
  .btn-save {
    background-color: #28a745;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
    margin-top: 10px;
  }
  
  .btn-save:hover {
    background-color: #218838;
  }
  
  .current-photo-container {
    margin-bottom: 15px;
  }
  
  .current-photo {
    max-width: 100px;
    max-height: 100px;
    border-radius: 4px;
    border: 1px solid #ddd;
  }
</style>
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="container">
  <h2>Manage Homepage Attorneys</h2>
  
  <div class="form-container">
    <h3>Add New Attorney</h3>
    <form action="" method="post" enctype="multipart/form-data">
      <div class="form-group">
        <label for="name">Attorney Name</label>
        <input type="text" id="name" name="name" required>
      </div>
      
      <div class="form-group">
        <label for="specialization">Specialization</label>
        <input type="text" id="specialization" name="specialization" required>
      </div>
      
      <div class="form-group">
        <label for="photo">Photo</label>
        <input type="file" id="photo" name="photo" accept="image/*" required>
      </div>
      
      <button type="submit" name="add_attorney" class="btn btn-primary">Add Attorney</button>
    </form>
  </div>
  
  <h3>Current Attorneys on Homepage</h3>
  
  <?php if ($attorneys->num_rows > 0): ?>
    <div class="table-responsive">
      <table class="attorney-table">
        <thead>
          <tr>
            <th>Photo</th>
            <th>Name</th>
            <th>Specialization</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($attorney = $attorneys->fetch_assoc()): ?>
            <tr>
              <td>
                <img src="img/<?= htmlspecialchars($attorney['photo']) ?>" alt="<?= htmlspecialchars($attorney['name']) ?>" class="attorney-thumbnail">
              </td>
              <td><?= htmlspecialchars($attorney['name']) ?></td>
              <td><?= htmlspecialchars($attorney['specialization']) ?></td>
              <td class="action-buttons">
                <button onclick="openEditModal(
                  <?= $attorney['id'] ?>,
                  '<?= htmlspecialchars($attorney['name'], ENT_QUOTES) ?>',
                  '<?= htmlspecialchars($attorney['specialization'], ENT_QUOTES) ?>',
                  'img/<?= htmlspecialchars($attorney['photo']) ?>'
                )" class="btn-edit">
                  <i class="fas fa-edit"></i> Edit
                </button>
                <a href="?delete=<?= $attorney['id'] ?>" class="btn-delete" onclick="return confirm('Are you sure you want to delete this attorney?')">
                  <i class="fas fa-trash"></i> Delete
                </a>
              </td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <div class="no-attorneys">
      <p>No attorneys added yet. Add some using the form above.</p>
    </div>
  <?php endif; ?>
</div>

<!-- Edit Modal -->
<div id="editModal" class="modal">
  <div class="modal-content">
    <span class="close" onclick="closeEditModal()">&times;</span>
    <h3>Edit Attorney</h3>
    <form id="editForm" method="post" enctype="multipart/form-data">
      <input type="hidden" name="id" id="editId">
      <input type="hidden" name="edit_attorney" value="1">
      
      <div class="form-group">
        <label for="editName">Name</label>
        <input type="text" id="editName" name="name" required>
      </div>
      
      <div class="form-group">
        <label for="editSpecialization">Specialization</label>
        <input type="text" id="editSpecialization" name="specialization" required>
      </div>
      
      <div class="form-group">
        <div class="current-photo-container">
          <label>Current Photo</label><br>
          <img id="currentPhoto" src="" class="current-photo">
        </div>
        <label for="editPhoto">Change Photo (Optional)</label>
        <input type="file" id="editPhoto" name="photo" accept="image/*">
      </div>
      
      <div style="text-align: right;">
        <button type="submit" class="btn-save">Save Changes</button>
      </div>
    </form>
  </div>
</div>

<script>
  function openEditModal(id, name, specialization, photoPath) {
    document.getElementById('editId').value = id;
    document.getElementById('editName').value = name;
    document.getElementById('editSpecialization').value = specialization;
    document.getElementById('currentPhoto').src = photoPath;
    
    // Reset modal position and show
    const modal = document.getElementById('editModal');
    modal.style.display = 'block';
    document.body.style.overflow = 'hidden'; // Prevent background scrolling
  }
  
  function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
    document.body.style.overflow = 'auto'; // Re-enable scrolling
  }
  
  // Close modal when clicking outside
  window.onclick = function(event) {
    const modal = document.getElementById('editModal');
    if (event.target == modal) {
      closeEditModal();
    }
  }
</script>
</body>
</html>

<?php
$conn->close();
?>