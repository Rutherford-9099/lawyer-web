<?php
include '../userlogin/conn.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $city = $_POST['city'];
    $service_type = $_POST['service_type'];
    $urgency = $_POST['urgency'];
    $budget = $_POST['budget'];
    $description = $_POST['description'];
    $lawyer_id = $_POST['lawyer_id']; // should come from hidden input in form

    // Get lawyer name from lawyer_id
    $lawyer_name = "";
    $stmt = $conn->prepare("SELECT name FROM lawyers WHERE id = ?");
    $stmt->bind_param("i", $lawyer_id);
    $stmt->execute();
    $stmt->bind_result($lawyer_name);
    $stmt->fetch();
    $stmt->close();

    // Insert into appointments
    $stmt2 = $conn->prepare("INSERT INTO appointments (name, email, phone, city, service_type, urgency, budget, description, lawyer_id, lawyer_name, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");

    $stmt2->bind_param("ssssssssss", $user_name, $email, $phone, $city, $service_type, $urgency, $budget, $description, $lawyer_id, $lawyer_name);

    if ($stmt2->execute()) {
        echo "<script>alert('Appointment submitted successfully!'); window.location.href='../findlawyer.php';</script>";
    } else {
        echo "Error: " . $stmt2->error;
    }

    $stmt2->close();
    $conn->close();
}
?>
