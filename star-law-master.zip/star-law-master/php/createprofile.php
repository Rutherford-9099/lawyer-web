<?php
session_start();
include '../userlogin/conn.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Create Lawyer Profile</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />

  <!-- FontAwesome for icons -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />

  <style>
    body {
      background: #111;
      color: #eee;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }

    .modal-content {
      background: #222;
      color: #eee;
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 0 25px #0af;
    }

    .modal-header {
      border-bottom: 1px solid #444;
      margin-bottom: 20px;
    }

    .form-label {
      font-weight: 600;
      color: #ccc;
    }

    .form-control {
      background: #333;
      border: 1px solid #555;
      color: #eee;
      border-radius: 8px;
    }

    .form-control:focus {
      border-color: #0af;
      box-shadow: 0 0 8px #0af;
      background: #222;
      color: #fff;
    }

    textarea.form-control {
      resize: vertical;
    }

    .input-group-text {
      background: #333;
      border: 1px solid #555;
      color: #0af;
      border-radius: 8px 0 0 8px;
      font-size: 1.1rem;
    }

::placeholder {
  color: #fff !important;
  opacity: 1;
}


    .btn-success {
      background-color: #00bfff;
      color: #000;
      border: none;
      font-weight: 700;
      border-radius: 12px;
      transition: background-color 0.3s ease, box-shadow 0.3s ease;
    }

    .btn-success:hover {
      background-color: #0099cc;
      color: #fff;
      box-shadow: 0 0 12px #00bfff;
    }

    .btn-close {
      background-color: #fff;
    }

    .mb-4 {
      margin-bottom: 1.5rem !important;
    }

    /* Scrollbar fix for textarea in dark */
    textarea.form-control::-webkit-scrollbar {
      width: 8px;
    }
    textarea.form-control::-webkit-scrollbar-thumb {
      background-color: #0af;
      border-radius: 4px;
    }
  </style>
</head>
<body>

<!-- Modal -->
<div class="modal show d-block" tabindex="-1" id="createProfileModal" aria-modal="true" role="dialog">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Create Lawyer Profile</h5>
    <button type="button" class="btn-close" aria-label="Close" onclick="window.location.href='../findlawyer.php'"></button>

      
      </div>

      <div class="modal-body">
        <form action="submit_profile.php" method="POST" enctype="multipart/form-data" novalidate>

          <div class="mb-4">
            <label class="form-label" for="name">Lawyer Name</label>
            <div class="input-group">
              <span class="input-group-text"><i class="fa fa-user"></i></span>
              <input type="text" class="form-control" id="name" name="name" placeholder="John Doe" required />
            </div>
          </div>

          <div class="mb-4">
            <label class="form-label" for="location">Location</label>
            <div class="input-group">
              <span class="input-group-text"><i class="fa fa-map-marker-alt"></i></span>
              <input type="text" class="form-control" id="location" name="location" placeholder="City, Country" required />
            </div>
          </div>

          <div class="mb-4">
            <label class="form-label" for="case_type">Case Type</label>
            <div class="input-group">
              <span class="input-group-text"><i class="fa fa-briefcase"></i></span>
              <input type="text" class="form-control" id="case_type" name="case_type" placeholder="Criminal, Civil, etc." required />
            </div>
          </div>

          <div class="mb-4">
            <label class="form-label" for="year_founded">Year Founded</label>
            <div class="input-group">
              <span class="input-group-text"><i class="fa fa-calendar-alt"></i></span>
              <input type="number" min="1900" max="2099" step="1" class="form-control" id="year_founded" name="year_founded" placeholder="e.g., 1998" required />
            </div>
          </div>

          <div class="mb-4">
            <label class="form-label" for="team_size">Team Size</label>
            <div class="input-group">
              <span class="input-group-text"><i class="fa fa-users"></i></span>
              <input type="number" min="1" class="form-control" id="team_size" name="team_size" placeholder="Number of team members" required />
            </div>
          </div>

          <div class="mb-4">
            <label class="form-label" for="languages">Languages</label>
            <div class="input-group">
              <span class="input-group-text"><i class="fa fa-language"></i></span>
              <input type="text" class="form-control" id="languages" name="languages" placeholder="English, Spanish, etc." required />
            </div>
          </div>

          <div class="mb-4">
            <label class="form-label" for="description">Description</label>
            <textarea class="form-control" id="description" name="description" rows="4" placeholder="Write a brief description..." required></textarea>
          </div>

          <div class="mb-4">
            <label class="form-label" for="image">Upload Image <small class="text-muted">(jpg, png, max 2MB)</small></label>
            <input type="file" class="form-control" id="image" name="image" accept="image/*" required />
          </div>

        
          <button type="submit" class="btn btn-success w-100">Submit Profile</button>
        </form>
      </div>
    </div>
  </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
 
  var myModal = new bootstrap.Modal(document.getElementById('createProfileModal'));
  myModal.show();

  document.getElementById('createProfileModal').addEventListener('hidden.bs.modal', function () {
   
    window.location.href = 'findlawyer.php';
  });
</script>

</body>
</html>
