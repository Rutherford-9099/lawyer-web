<?php
session_start();
include '../userlogin/conn.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // File upload handling
    $target_dir = "uploads/";
    if(!is_dir($target_dir)) {
        mkdir($target_dir, 0755, true);
    }

    $uploads = basename($_FILES["image"]["name"]);
    $target_file = $target_dir . $uploads;

    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
        // Success
    } else {
        die("Error uploading image");
    }

    // Removed facebook, twitter, instagram from here
    $stmt = $conn->prepare("INSERT INTO lawyers (name, location, case_type, year_founded, team_size, languages, description, image, is_approved) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)");

    $stmt->bind_param("ssssssss", 
        $_POST['name'],
        $_POST['location'],
        $_POST['case_type'],
        $_POST['year_founded'],
        $_POST['team_size'],
        $_POST['languages'],
        $_POST['description'],
        $target_file
    );

    if ($stmt->execute()) {
        // Show success message and redirect
        echo '<!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1" />
            <title>Profile Submitted</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
            <style>
                body {
                    background-color: #000;
                    color: white;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                    text-align: center;
                }
                .success-message {
                    background-color: #343a40;
                    padding: 30px;
                    border-radius: 15px;
                    box-shadow: 0 5px 15px rgba(0,0,0,0.3);
                }
                .checkmark {
                    font-size: 50px;
                    color: #28a745;
                    margin-bottom: 20px;
                }
            </style>
        </head>
        <body>
            <div class="success-message">
                <div class="checkmark">✓</div>
                <h2>Profile Submitted Successfully!</h2>
                <p>Your profile has been sent to admin for approval.</p>
                <p>It will be reviewed and updated within 2 hours.</p>
                <p>Redirecting back to Find Lawyer page...</p>
            </div>
            <script>
                setTimeout(function() {
                    window.location.href = "../findlawyer.php";
                }, 5000);
            </script>
        </body>
        </html>';
    } else {
        echo "Error: " . $stmt->error;
    }
    
    $stmt->close();
}
$conn->close();
?>
