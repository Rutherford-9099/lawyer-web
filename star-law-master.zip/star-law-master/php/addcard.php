<?php
session_start();
include '../userlogin/conn.php';
?>

$result = $conn->query("SELECT * FROM lawyers WHERE is_approved = 1");

while ($row = $result->fetch_assoc()) {
  echo '
  <div class="col-md-4">
    <div class="law-card" data-name="'.$row['name'].'" data-location="'.$row['location'].'" data-case="'.$row['case_type'].'">
      <div class="law-header">
        <img src="uploads/'.$row['image'].'" alt="Logo">
        <div class="law-name">
          <h4>'.$row['name'].'<br><p style="font-size: 12px;">'.$row['location'].'</p></h4>
          <a href="#" class="view-btn">View Profile</a>
        </div>
      </div>
      <div class="law-type" style="display:inline-block; padding:4px 8px; background-color:#007bff; color:#fff; border-radius:5px; font-size:13px;">
        '.$row['case_type'].'
      </div>
      <div class="law-meta">
        <p><i class="far fa-calendar-alt"></i> Founded in '.$row['year_founded'].'</p>
        <p><i class="fas fa-users"></i> '.$row['team_size'].' people in team</p>
      </div>
      <div class="languages">';
        $langs = explode(",", $row['languages']);
        foreach ($langs as $lang) echo "<span>".trim($lang)."</span>";
      echo '</div>
      <p class="law-description">'.$row['description'].'</p>
      <div class="social-icons" style="text-align: center;">
        <a href="'.$row['facebook'].'"><i class="fab fa-facebook fa-lg"></i></a>
        <a href="'.$row['twitter'].'"><i class="fab fa-twitter fa-lg"></i></a>
        <a href="'.$row['instagram'].'"><i class="fab fa-instagram fa-lg"></i></a>
      </div>
    </div>
  </div>';
}

$conn->close();
?>
