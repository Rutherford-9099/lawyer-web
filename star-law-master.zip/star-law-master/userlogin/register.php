<?php
session_start();
include 'conn.php';

if (isset($_POST['register'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    // Password stored as plain text (not recommended for real apps)
    $password = $conn->real_escape_string($_POST['password']);
    $user_type = $conn->real_escape_string($_POST['user_type']);

    // Check if email already exists
    $check = $conn->query("SELECT id FROM users WHERE email='$email'");
    if ($check->num_rows > 0) {
        $_SESSION['message'] = "Email already registered. Please login.";
        $_SESSION['msg_type'] = 'error';
    } else {
        $stmt = $conn->prepare("INSERT INTO users (name, email, password, user_type) VALUES (?, ?, ?, ?)");
        if ($stmt) {
            $stmt->bind_param("ssss", $name, $email, $password, $user_type);
            if ($stmt->execute()) {
                $_SESSION['user_email'] = $email;
                $_SESSION['user_type'] = $user_type;

                switch ($user_type) {
                    case 'admin':
                        header("Location: ../admin_dashboard.php");
                        exit();
                    case 'lawyer':
                        header("Location: ../lawyer_dashboard.php");
                        exit();
                    default:
                        header("Location: ../findlawyer.php");
                        exit();
                }
            } else {
                $_SESSION['message'] = "Registration failed. Please try again.";
                $_SESSION['msg_type'] = 'error';
            }
            $stmt->close();
        } else {
            $_SESSION['message'] = "Database error: prepare failed.";
            $_SESSION['msg_type'] = 'error';
        }
    }
}
?>


<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            background: #111;
            color: #fff;
            font-family: Arial;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .box {
            background: #222;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px #0af;
            width: 320px;
        }
        h2 {
            text-align: center;
            color: #00bfff;
        }
        input, select, button {
            width: 100%;
            margin: 12px 0;
            padding: 10px;
            border: none;
            border-radius: 6px;
            background: #333;
            color: #fff;
        }
        button {
            background: #00bfff;
            color: #000;
            font-weight: bold;
            cursor: pointer;
        }
        .message {
            padding: 10px;
            border-radius: 4px;
            margin-top: 10px;
            text-align: center;
        }
        .error { background: #440000; color: #f55; }
        .success { background: #004400; color: #5f5; }
    </style>
</head>
<body>
    <div class="box">
        <h2>Register</h2>
        <form method="POST">
            <input type="text" name="name" placeholder="Full Name" required>
            <input type="email" name="email" placeholder="Email Address" required>
            <input type="password" name="password" placeholder="Password" required minlength="6">
            <select name="user_type" required>
                <option value="">Select Account Type</option>
                <option value="user">User</option>
                <option value="lawyer">Lawyer</option>
                <option value="admin">Admin</option>
            </select>
            <button type="submit" name="register">Create Account</button>
        </form>

        <?php
        if (isset($_SESSION['message'])) {
            $class = $_SESSION['msg_type'] === 'error' ? 'error' : 'success';
            echo '<div class="message ' . $class . '">' . $_SESSION['message'] . '</div>';
            unset($_SESSION['message']);
            unset($_SESSION['msg_type']);
        }
        ?>
    </div>
</body>
</html>
