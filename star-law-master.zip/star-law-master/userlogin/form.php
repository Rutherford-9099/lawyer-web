<?php
session_start();
include 'conn.php';

// Get user_id from session (default 1 if not logged in)
$user_id = $_SESSION['user_id'] ?? 1;

// Get lawyer_id from URL (?lawyer_id=) or form POST (after submit), default to 1
$lawyer_id = $_GET['lawyer_id'] ?? $_POST['lawyer_id'] ?? 1;

if (isset($_POST['submit'])) {
    $status = 'Pending';

    // Sanitize inputs
    $first_name = htmlspecialchars(trim($_POST['first_name']));
    $last_name = htmlspecialchars(trim($_POST['last_name']));
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $phone = htmlspecialchars(trim($_POST['phone']));
    $city = htmlspecialchars(trim($_POST['city']));
    $service_type = htmlspecialchars(trim($_POST['service_type']));
    $urgency = htmlspecialchars(trim($_POST['urgency']));
    $budget = htmlspecialchars(trim($_POST['budget']));
    $description = htmlspecialchars(trim($_POST['description']));

    // Prepare insert statement
    $stmt = $conn->prepare("INSERT INTO appointments 
        (first_name, last_name, email, phone, city, service_type, urgency, budget, description, status, user_id, lawyer_id) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    $stmt->bind_param(
        "ssssssssssii",
        $first_name,
        $last_name,
        $email,
        $phone,
        $city,
        $service_type,
        $urgency,
        $budget,
        $description,
        $status,
        $user_id,
        $lawyer_id
    );

    if ($stmt->execute()) {
        echo '<!DOCTYPE html>
        <html>
        <head>
            <style>
                body { background: #111; color: #fff; font-family: Arial; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
                .message-box { background: #222; padding: 30px; border-radius: 10px; box-shadow: 0 0 10px #0af; width: 400px; text-align: center; }
                .success-icon { color: #0f0; font-size: 50px; margin-bottom: 20px; }
            </style>
            <meta http-equiv="refresh" content="7;url=../findlawyer.php">
        </head>
        <body>
            <div class="message-box">
                <div class="success-icon">✓</div>
                <h2>Appointment Submitted Successfully!</h2>
                <p>Your appointment has been received. We will contact you soon.</p>
                <p>You will be redirected back in 7 seconds...</p>
            </div>
        </body>
        </html>';
        $stmt->close();
        exit();
    } else {
        echo "Error: " . $stmt->error;
        $stmt->close();
        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <style>
        body { background: #111; color: #fff; font-family: Arial; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .box { background: #222; padding: 30px; border-radius: 10px; box-shadow: 0 0 10px #0af; width: 400px; }
        input, select, textarea, button { width: 100%; margin: 10px 0; padding: 10px; border: none; border-radius: 5px; background: #333; color: #fff; }
        button { background: #00bfff; color: #000; font-weight: bold; cursor: pointer; }
        textarea { height: 100px; resize: vertical; }
    </style>
</head>
<body>
    <div class="box">
        <h2>Appointment Request</h2>
        <form method="POST" action="">
            <!-- Hidden lawyer_id -->
            <input type="hidden" name="lawyer_id" value="<?= htmlspecialchars($lawyer_id) ?>">

            <input type="text" name="first_name" placeholder="First name" required>
            <input type="text" name="last_name" placeholder="Last name" required>
            <input type="email" name="email" placeholder="Email address" required>
            <input type="text" name="phone" placeholder="Phone number" required>
            <input type="text" name="city" placeholder="City" required>

            <select name="service_type" required>
                <option value="" disabled selected>Type of Service</option>
                <option value="Family Law">Family Law</option>
                <option value="Business Law">Business Law</option>
                <option value="Criminal Law">Criminal Law</option>
            </select>

            <select name="urgency" required>
                <option value="" disabled selected>Urgency</option>
                <option value="Immediately">Immediately</option>
                <option value="This week">This week</option>
            </select>

            <select name="budget" required>
                <option value="" disabled selected>Budget</option>
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
            </select>

            <textarea name="description" placeholder="Describe your case" required></textarea>

            <button type="submit" name="submit">Submit</button>
        </form>
    </div>
</body>
</html>
