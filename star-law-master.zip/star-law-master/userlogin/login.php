<?php
session_start();
include 'conn.php'; // contains $conn = new mysqli(...)

if (isset($_POST['login'])) {
    $email = $conn->real_escape_string($_POST['email']);
    $password = $conn->real_escape_string($_POST['password']);

    $res = $conn->query("SELECT * FROM users WHERE email='$email'");

    if ($res->num_rows > 0) {
        $row = $res->fetch_assoc();

        // Plain text password comparison (not secure)
        if ($password === $row['password']) {
            $_SESSION['user_email'] = $row['email'];
            $_SESSION['user_type'] = $row['user_type'];

            switch ($row['user_type']) {
                case 'admin':
                    header("Location: ../admin_dashboard.php");
                    break;
                case 'lawyer':
                    header("Location: ../lawyer_dashboard.php");
                    break;
                case 'user':
                default:
                    header("Location: ../findlawyer.php");
                    break;
            }
            exit();
        } else {
            $_SESSION['message'] = "❌ Incorrect password!";
            $_SESSION['msg_type'] = "error";
        }
    } else {
        $_SESSION['message'] = "🚫 Account not found. Please register.";
        $_SESSION['msg_type'] = "error";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            background: #111;
            color: #fff;
            font-family: Arial;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .box {
            background: #222;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px #0af;
            width: 300px;
            text-align: center;
        }
        input, button {
            width: 100%;
            margin: 10px 0;
            padding: 10px;
            border: none;
            border-radius: 5px;
            box-sizing: border-box;
        }
        input {
            background: #333;
            color: #fff;
        }
        button {
            background: #00bfff;
            color: #000;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s;
        }
        button:hover {
            background: #0080ff;
        }
        .secondary-btn {
            background: transparent;
            color: #00bfff;
            border: 1px solid #00bfff;
            margin-top: 5px;
        }
        .secondary-btn:hover {
            background: rgba(0, 191, 255, 0.1);
        }
        .error {
            color: #ff4444;
            background: rgba(255, 68, 68, 0.1);
            border-radius: 4px;
            padding: 8px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="box">
        <h2>Login</h2>

        <?php
        if (isset($_SESSION['message'])) {
            echo '<div class="error">' . $_SESSION['message'] . '</div>';
            unset($_SESSION['message']);
            unset($_SESSION['msg_type']);
        }
        ?>

        <form method="POST">
            <input type="email" name="email" placeholder="Email address" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" name="login">Login</button>

            <button type="button" class="secondary-btn" onclick="window.location='register.php'">
                Create Account
            </button>
        </form>
    </div>
</body>
</html>
