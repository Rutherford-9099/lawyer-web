<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>



<nav class="navbar navbar-default header_aera affix-top">
    <div class="container m-s">
        <div class="col-md-4 p0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                    data-target="#min_navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand logo-biss" href="index.php"> Star Law Firm </a>
            </div>
        </div>
        <div class="col-md-8 p0">
            <div class="collapse navbar-collapse" id="min_navbar">
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown submenu">
                        <a href="index.php" class="">Home</a>
                    </li>
                    <li class="dropdown submenu">
                        <a href="about.php" class="">About</a>
                    </li>
                    <li class="dropdown submenu">
                        <a href="services.php" class="">Services</a>
                    </li>
                    <li><a href="findlawyer.php"><i class="fa-solid fa-magnifying-glass"></i> Find a Lawyer</a></li>
                    <li class="dropdown submenu">
                        <a href="contact.php" class="">Contact</a>
                    </li>
                    <?php if (isset($_SESSION['user_email'])): ?>
                        <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                    <?php else: ?>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fas fa-user"></i> Login <b class="caret"></b>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a href="userlogin/login.php" style="color: black;">As Client</a></li>
                                <li><a href="userlogin/login.php">As Lawyer</a></li>
                                <li><a href="admin_login.php">As Admin</a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</nav>
