<?php
include 'userlogin/conn.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title>About Page </title>
   <!-- Favicon -->
   <!-- Font Awesome CDN -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

   <!-- Bootstrap CSS -->
   <link href="assets/css/bootstrap.min.css" rel="stylesheet">
   <!-- Animate CSS -->
   <link href="assets/vendors/animate/animate.css" rel="stylesheet">
   <!-- Icon CSS-->
   <link rel="stylesheet" href="assets/vendors/font-awesome/css/font-awesome.min.css">
   <!-- Owlcarousel CSS-->
   <link rel="stylesheet" type="text/css" href="assets/vendors/owl_carousel/owl.carousel.css" media="all">
   <!--Template Styles CSS-->
   <link rel="stylesheet" type="text/css" href="assets/css/style.css" media="all" />
   <link
      href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600,600i,700,700i,800,800i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese"
      rel="stylesheet">
</head>

<body>
   <div class="about-banner-img">
      <div class="ovrllay">
         <!-- Header_Area -->
         <nav class="navbar navbar-default header_aera affix-top">
            <div class="container m-s">
               <!-- Brand and toggle get grouped for better mobile display -->
               <div class="col-md-4 p0">
                  <div class="navbar-header">
                     <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                        data-target="#min_navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                     </button>
                     <a class="navbar-brand logo-biss" href="index.html"> Star Law Firm </a>
                  </div>
               </div>
               <!-- Collect the nav links, forms, and other content for toggling -->
               <div class="col-md-8 p0">
                  <div class="collapse navbar-collapse" id="min_navbar">
                     <ul class="nav navbar-nav navbar-right">
                        <li class="dropdown submenu">
                           <a href="index.php" class="">Home</a>
                        </li>
                        <li class="dropdown submenu">
                           <a href="about.php" class="">About</a>
                        </li>
                        <li class="dropdown submenu">
                           <a href="services.php" class=""> Services</a>
                        </li>
                        <li><a href="findlawyer.php"><i class="fa-solid fa-magnifying-glass"></i> Find a Lawyer</a></li>

                        <li class="dropdown submenu">
                           <a href="contact.php" class="">Contact</a>
                        </li>
                        <?php if (isset($_SESSION['user_email'])): ?>
                        <!-- If logged in, show logout -->
                        <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                        <?php else: ?>
                        <!-- Show login options -->
                        <li class="dropdown">
                           <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                              <i class="fas fa-user"></i> Login <b class="caret"></b>
                           </a>
                           <ul class="dropdown-menu">
                              <li><a href="userlogin/login.php" style="color: black;">As Client</a></li>
                              <li><a href="userlogin/login.php">As Lawyer</a></li>
                              <li><a href="admin_login.php">As Admin</a></li>
                           </ul>
                        </li>
                        <?php endif; ?>
                     </ul>
                  </div>
                  <!-- /.navbar-collapse -->
               </div>
            </div>
            <!-- /.container -->
         </nav>
         <!-- End Header_Area -->
         <!-- #banner start -->
         <section id="banner" class="pb_0">
            <div class="container">
               <div class="row py-70 mb_160">
                  <!-- #banner-text start -->
                  <div id="banner-text" class="col-md-12 text-c">
                     <div class="left-borders">
                        <h5 class="wow fadeInUp main-about_h" data-wow-delay="0.2s">Who We Are</h5>
                        <p class="banner-text wow fadeInUp main-h3" data-wow-delay="0.8s">
                           <span class="c_yellow">ABOUT US</span> | COMMITTED TO EXCELLENCE <br>
                           IN LEGAL SERVICES
                        </p>
                     </div>
                  </div>
                  <!-- /#banner-text End -->
               </div>
            </div>
         </section>

      </div>
   </div>
   <!-- /#banner end -->
   <!-- #service Us Area start -->
   <div id="about">
      <div class="container">
         <div class="row top_service">
            <!--#about-text start -->
            <div class="who_we_area col-md-4 col-sm-6 wow fadeInUp">
               <div class="service_banner green-after">
                  <div class="wow fadeInUp">
                     <img src="assets/images/about-service1.png">
                  </div>
                  <h2>Trusted <br>Legal Experts</h2>
                  <p>Our legal team is here to support you.</p>
               </div>
            </div>
            <div class="who_we_area col-md-4 col-sm-6 wow fadeInUp">
               <div class="service_banner pink-after">
                  <div class="wow fadeInUp">
                     <img src="assets/images/about-service2.png">
                  </div>
                  <h2>30+ Years <br>Experience</h2>
                  <p>Our lawyers bring years of expertise.</p>
               </div>
            </div>
            <div class="who_we_area col-md-4 col-sm-6 wow fadeInUp">
               <div class="service_banner purple-after">
                  <div class="wow fadeInUp">
                     <img src="assets/images/about-service3.png">
                  </div>
                  <h2>Achievements <br>and Honors</h2>
                  <p>Our firm has earned legal recognition.</p>
               </div>
            </div>
            <!--#End about-text  -->
         </div>
      </div>
   </div>
   <!-- End service Us Area -->

   <!-- #Experienced Us Area start -->
   <div id="about" class="bg_Consultation pt-70">
      <div class="container">
         <div class="row  ">
            <!--#about-text start -->

            <div class="who_we_area title text-left col-md-4 col-sm-6 col-4pad wow fadeInUp">
               <h1 class="c_brown"> We are <br>Experienced <br>Trial Lawyers </h1>
            </div>
            <div class="who_we_area col-md-8  col-sm-6 col-4pad wow fadeInUp">
               <p class="about-bottom-s c_f  wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
                  We provide trusted legal support backed by years of courtroom experience. Our team is dedicated to
                  protecting your rights and achieving the best outcome for every client.
               </p>
               <div class="top-contact wow fadeInRight text-right"
                  style="visibility: visible; animation-name: fadeInRight;">
                  <a type="submit" id="#services" href="#services"
                     class="btn btn-default bg_tree wow fadeInUp  js-scroll-trigger " data-wow-delay="0.5s"
                     style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInUp;"> READ MORE</a>
               </div>
            </div>

         </div>
         <div class="row  mt-50 bottom_service">
            <!--#about-text start -->
            <div class="who_we_area title text-left p0 Lawyers_one col-md-4 col-sm-6  wow fadeInUp">
               <div class="ovrllay">
                  <div class="inner_text">
                     <h1><a href="contact.php"> Free Consultation </a> </h1>
                  </div>
               </div>
            </div>
            <div class="who_we_area title text-left p0 Lawyers_to col-md-4 col-sm-6 wow fadeInUp">
               <div class="ovrllay">
                  <div class="inner_text">
                     <h1><a href="contact.findlawyer.php"> Legal Information</a> </h1>
                  </div>
               </div>
            </div>
            <div class="who_we_area title text-left p0 Lawyers_tree col-md-4 col-sm-6 wow fadeInUp">
               <div class="ovrllay">
                  <div class="inner_text">
                     <h1><a href="index.php"> Proven Results</a> </h1>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <!-- #Experienced Us Area End -->
  <div id="about" class="bg_gradient_team py-70">
   <div class="container">
      <div class="row about_row  py-40">
         <!--#about-text start -->
         <div class="who_we_area title text-left col-md-8 col-sm-6 col-4pad wow fadeInUp">
            <h1 class=""> STAR LEE LAW FIRM </h1>
            <p class="about-bottom-s  wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
               At Star Lee Law Firm, we are committed to delivering trusted legal representation with integrity and dedication. For decades, our attorneys have defended clients across a wide range of legal challenges. We blend tradition with modern legal strategies to ensure effective outcomes. With a strong reputation and personalized service, we stand by our clients every step of the way.
            </p>
         </div>
         <div class="who_we_area col-md-4 text-right col-sm-6 col-4pad wow fadeInUp">
            <img src="assets/images/about-main.png" class="border_img">
         </div>
      </div>
   </div>
</div>

   <!-- End About Us Area -->
<section class="attorney-section" style="padding: 100px 0; background: #f4f6f9;">
  <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 0 15px;">
    <div class="section-header" style="text-align: center; margin-bottom: 60px;">
      <h2 style="font-size: 42px; font-weight: 700; color: #1a2a3a; margin-bottom: 10px; position: relative;">
        Our Legal Experts
      </h2>
      <p style="font-size: 18px; color: #6b7280; max-width: 700px; margin: 0 auto; line-height: 1.7;">
        Meet our team of experienced attorneys dedicated to providing exceptional legal services with integrity and excellence.
      </p>
    </div>

    <div class="attorney-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 30px;">
      <?php
      $result = $conn->query("SELECT * FROM homepage_attorneys ORDER BY id DESC LIMIT 3");

      if ($result->num_rows > 0) {
          while ($row = $result->fetch_assoc()) {
              echo '
              <a href="findlawyer.php?id='.$row['id'].'" class="attorney-card-link" style="text-decoration: none; color: inherit;">
                <div class="attorney-card" style="background: #fff; border-radius: 16px; overflow: hidden; box-shadow: 0 8px 24px rgba(0,0,0,0.08); transition: transform 0.3s ease, box-shadow 0.3s ease; cursor: pointer;">
                  <div class="card-image" style="height: 360px; overflow: hidden; position: relative;">
                    <img src="admin/img/'.$row['photo'].'" alt="'.$row['name'].'" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;">
                    <div class="social-links" style="position: absolute; bottom: 20px; left: 0; right: 0; display: flex; justify-content: center; gap: 12px; opacity: 0; transform: translateY(20px); transition: all 0.4s ease;">
                      <span style="width: 38px; height: 38px; background: #3a86ff; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                        <i class="fab fa-linkedin-in"></i>
                      </span>
                      <span style="width: 38px; height: 38px; background: #3a86ff; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                        <i class="fas fa-envelope"></i>
                      </span>
                      <span style="width: 38px; height: 38px; background: #3a86ff; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                        <i class="fas fa-phone-alt"></i>
                      </span>
                    </div>
                  </div>
                  <div class="card-content" style="padding: 25px 20px; text-align: center;">
                    <h3 style="font-size: 24px; font-weight: 700; color: #1a2a3a; margin-bottom: 8px;">'.$row['name'].'</h3>
                    <p style="color: #3a86ff; font-weight: 600; margin-bottom: 12px; font-size: 14px; text-transform: uppercase; letter-spacing: 1px;">'.$row['specialization'].'</p>
                    <div style="width: 50px; height: 2px; background: #e5e7eb; margin: 0 auto 10px;"></div>
                  </div>
                </div>
              </a>';
          }
      } else {
          echo '
          <a href="findlawyer.php" class="attorney-card-link" style="text-decoration: none; color: inherit;">
            <div class="attorney-card" style="background: #fff; border-radius: 16px; overflow: hidden; box-shadow: 0 8px 24px rgba(0,0,0,0.08); transition: transform 0.3s ease, box-shadow 0.3s ease; cursor: pointer;">
              <div class="card-image" style="height: 360px; overflow: hidden; position: relative;">
                <img src="assets/images/team-1.png" alt="Default Attorney" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;">
                <div class="social-links" style="position: absolute; bottom: 20px; left: 0; right: 0; display: flex; justify-content: center; gap: 12px; opacity: 0; transform: translateY(20px); transition: all 0.4s ease;">
                  <span style="width: 38px; height: 38px; background: #3a86ff; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                    <i class="fab fa-linkedin-in"></i>
                  </span>
                  <span style="width: 38px; height: 38px; background: #3a86ff; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-envelope"></i>
                  </span>
                  <span style="width: 38px; height: 38px; background: #3a86ff; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-phone-alt"></i>
                  </span>
                </div>
              </div>
              <div class="card-content" style="padding: 25px 20px; text-align: center;">
                <h3 style="font-size: 24px; font-weight: 700; color: #1a2a3a; margin-bottom: 8px;">JOHN DOE</h3>
                <p style="color: #3a86ff; font-weight: 600; margin-bottom: 12px; font-size: 14px; text-transform: uppercase; letter-spacing: 1px;">Criminal Lawyer</p>
                <div style="width: 50px; height: 2px; background: #e5e7eb; margin: 0 auto 10px;"></div>
                <p style="color: #6b7280; font-size: 14px; margin-top: 10px;">
                  <i class="fas fa-award" style="margin-right: 5px; color: #3a86ff;"></i> 10+ Years Experience
                </p>
              </div>
            </div>
          </a>';
      }
      ?>
    </div>
  </div>
</section>
   <!--End team Area -->
   <!-- #The History Us Area Start -->
   <section class="">
      <div class="container">
         <div class="row text-center  ">
            <div class="title wow fadeInUp">
               <h1>The History</h1>
               <div class="hed_img">
                  <img src="assets/images/headding-img.png">
               </div>
               <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem <br> Ipsum has been
                  the industry's standard. </p>
            </div>
         </div>
         <div class="row mt-100">
            <ul class="timeline">
               <li class="wow fadeInUp">
                  <div class="timeline-badge">
                     <a><i class="fa fa-circle" id=""></i></a>
                  </div>
                  <div class="timeline-panel">
                     <div class="timeline-body">
                        <img src="assets/images/timeline3.png">

                     </div>
                     <div class="timeline-footer">
                        <h1>
                           Property Crime
                        </h1>
                        <p class="c_f">Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots
                           in a piece of classical Latin.</p>
                     </div>
                  </div>
               </li>
               <li class="timeline-inverted wow fadeInUp">
                  <div class="timeline-badge">
                     <a><i class="fa fa-circle invert" id=""></i></a>
                  </div>
                  <div class="timeline-panel">
                     <div class="timeline-body">

                        <p class="img_left"> 2003 usa </p>
                     </div>

                  </div>
               </li>
               <li class="wow fadeInUp">
                  <div class="timeline-badge">
                     <a><i class="fa fa-circle" id=""></i></a>
                  </div>
                  <div class="timeline-panel">
                     <div class="timeline-body">

                        <p class="img_top"> 2007 usa </p>
                     </div>

                  </div>
               </li>
               <li class="timeline-inverted  wow fadeInUp">
                  <div class="timeline-badge">
                     <a><i class="fa fa-circle invert" id=""></i></a>
                  </div>
                  <div class="timeline-panel">

                     <div class="timeline-footer">
                        <h1> building construction case </h1>
                        <p class="c_f">Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots
                           in a piece of classical Latin.</p>
                     </div>
                  </div>
               </li>

               <li class="wow fadeInUp mt_560">
                  <div class="timeline-badge">
                     <a><i class="fa fa-circle" id=""></i></a>
                  </div>
                  <div class="timeline-panel">
                     <div class="timeline-body">
                        <img src="assets/images/timeline4.png">

                     </div>
                     <div class="timeline-footer">
                        <h1> building construction case </h1>
                        <p class="c_f">Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots
                           in a piece of classical Latin.</p>
                     </div>
                  </div>
               </li>
               <li class="timeline-inverted wow fadeInUp">
                  <div class="timeline-badge">
                     <a><i class="fa fa-circle invert" id=""></i></a>
                  </div>
                  <div class="timeline-panel">
                     <div class="timeline-body">

                        <p class="img_left"> 2014 usa </p>
                     </div>

                  </div>
               </li>

               <li class="wow fadeInUp">
                  <div class="timeline-badge">
                     <a><i class="fa fa-circle" id=""></i></a>
                  </div>
                  <div class="timeline-panel">
                     <div class="timeline-body">

                        <p class="img_top"> 2016 usa </p>
                     </div>

                  </div>
               </li>
               <li class="timeline-inverted  wow fadeInUp">
                  <div class="timeline-badge">
                     <a><i class="fa fa-circle invert" id=""></i></a>
                  </div>
                  <div class="timeline-panel">

                     <div class="timeline-footer">
                        <h1>road accident usa </h1>
                        <p class="c_f">Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots
                           in a piece of classical Latin.</p>
                     </div>
                  </div>
               </li>
               <li class="clearfix no-float"></li>
            </ul>
         </div>
      </div>
   </section>
   <!-- #History Us Area End -->
   <div class="our_partners_area bg_gradient_team">
      <div class="book_now_aera ">
         <div class="container">
            <div class="row book_now">
               <div class="col-md-7 booking_text">
                  <h4>Lorem Ipsum is simply dummy text of the printing and<br> typesetting industry.
                  </h4>
                  <p>Get started for free to see who your customers are, what they do and what keeps them coming back.
                  </p>
               </div>
               <div class="col-md-5 p0 book_bottun">
                  <div class="col-md-5">
                  </div>
                  <div class="col-md-7">
                     <div class="top-banner wow fadeInRight text-left"
                        style="visibility: visible; animation-name: fadeInRight;">
                        <a id="#services" href="contact.html"
                           class="btn btn-primary radius-50  wow fadeInUp  js-scroll-trigger" data-wow-delay="0.5s"
                           style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInUp;">Free
                           Consultation</a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <!--#start Our footer Area -->
   <?php include 'footer.php'; ?>

   <!--#End Our footer Area -->
   <!-- jQuery JS -->
   <script src="assets/js/jquery-1.12.0.min.js"></script>
   <!-- Bootstrap JS -->
   <script src="assets/js/bootstrap.min.js"></script>

   <!-- Animate JS -->
   <script src="assets/vendors/animate/wow.min.js"></script>
   <!-- Owlcarousel JS -->
   <script src="assets/vendors/owl_carousel/owl.carousel.min.js"></script>
   <!-- Stellar JS -->
   <!-- Theme JS -->
   <script src="assets/js/theme.min.js"></script>
</body>

</html>