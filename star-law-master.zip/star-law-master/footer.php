<!-- footer.php -->
<!--#start Our footer Area -->
<div class="our_footer_area" style="background-color: #111; color: #fff; padding: 50px 0;">
    <div class="book_now_aera">
        <div class="container wow fadeInUp">
            <div class="row book_now">
                <div class="col-md-4">
                    <a class="logo-biss" href="index.php" style="font-size: 24px; font-weight: bold; color: #ff014f;">Star Law Firm</a>
                    <p class="footer-h" style="margin-top: 15px;">
                        It is a long established fact that a <br>reader will be distracted by the <br> readable content.
                    </p>
                    <div class="bigpixi-footer-social" style="margin-top: 20px;">
                        <a href="https://www.facebook.com" target="_blank"><i class="fa fa-facebook fa-2x social"></i></a>
                        <a href="https://www.twitter.com" target="_blank"><i class="fa fa-twitter fa-2x social"></i></a>
                        <a href="https://www.instagram.com" target="_blank"><i class="fa fa-instagram fa-2x social"></i></a>
                    </div>
                </div>

                <div class="col-md-1"></div>

                <div class="col-md-3">
                    <h2 class="footer-top footer-heading">QUICK LINKS</h2>
                    <ul class="footer-menu" style="list-style: none; padding: 0;">
                        <li><a href="index.php">HOME</a></li>
                        <li><a href="about.php">ABOUT US</a></li>
                        <li><a href="services.php">SERVICES</a></li>
                        <li><a href="findlawyer.php">FIND A LAWYER</a></li>
                        <li><a href="contact.php">CONTACT</a></li>
                    </ul>
                </div>

                <div class="col-md-4">
                    <h2 class="footer-top footer-heading">Contact Info</h2>
                    <ul class="location" style="list-style: none; padding: 0;">
                        <li class="footer-left-h" style="margin-bottom: 10px;">505 Thornall St #301, <br>Edison, NJ 08837, USA</li>
                        <li class="footer-left-h" style="margin-bottom: 10px;"><span class="c_yellow">Email :</span>
                            <a href="mailto:enquiry@demo.com" style="color: #fff; text-decoration: none;"> enquiry@demo.com</a>
                        </li>
                        <li class="footer-left-h"><span class="c_yellow">Call Us: </span>+1-982-8-587 452</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!--#End Our footer Area -->

<!-- Hover Effects -->
<style>
    .footer-menu a {
        color: #fff;
        text-decoration: none;
        display: block;
        margin-bottom: 8px;
        transition: 0.3s;
    }

    .footer-menu a:hover {
        color: #ff014f !important;
        transform: translateX(5px);
    }

    .footer-heading {
        transition: 0.3s;
    }

    .footer-heading:hover {
        color: #ff014f;
        transform: scale(1.05);
    }

    .bigpixi-footer-social a {
        margin-right: 10px;
        color: #ff014f;
        transition: 0.3s;
    }

    .bigpixi-footer-social a:hover {
        transform: scale(1.2);
    }
</style>
