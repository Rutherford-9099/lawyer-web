<?php
session_start();
if (!isset($_SESSION['user_email'])) {
  header("Location: userlogin/login.php?redirect=findlawyer.php");
  exit();
}

$servername = "localhost";
$username = "root";
$password = ""; // apna password yahan do
$database = "lawyer_website";  // yeh database name fix karo

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$search = isset($_GET['search']) ? $_GET['search'] : '';

$sql = "SELECT * FROM lawyers WHERE is_approved = 1";

if (!empty($search)) {
  $search = $conn->real_escape_string($search);
  $sql .= " AND (name LIKE '%$search%' OR location LIKE '%$search%' OR case_type LIKE '%$search%')";
}

$result = $conn->query($sql);
if (!$result) {
    die("Query failed: " . $conn->error);
}
?>




<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Find a Lawyer</title>
  <!-- Font Awesome CDN -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

      <link href="assets/css/bootstrap.min.css" rel="stylesheet">
      <!-- Animate CSS -->
      <link href="assets/vendors/animate/animate.css" rel="stylesheet">
      <!-- Icon CSS-->
      <link rel="stylesheet" href="assets/vendors/font-awesome/css/font-awesome.min.css">
      <!-- Owlcarousel CSS-->
      <link rel="stylesheet" type="text/css" href="assets/vendors/owl_carousel/owl.carousel.css" media="all">
      <!--Template Styles CSS-->
      <link rel="stylesheet" type="text/css" href="assets/css/style.css" media="all" />
  <style>
    body {
      background: url('assets/images/background\ search\ card.png') no-repeat center center fixed;
      background-size: cover;
      color: #fff;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      padding-top: 0 !important;
    }

    /* Fixed Header Area */
    .header_aera {
      background: transparent !important;
      margin-top: 60px;
      padding: 10px 0;
      width: 100%;
      position: relative;
      z-index: 9999;
      border: none;
    }

    .header_aera .navbar-header {
      padding: 0;
    }

    .header_aera .navbar-brand {
      padding: 10px 15px !important;
      height: auto;
      color: white !important;
      text-transform: uppercase;
      /* margin-top: 0px; */
      font-size: 30px;
      font-weight: 700;
    }

    .header_aera .navbar-nav>li>a {
      padding: 15px 20px !important;
      color: white !important;
      font-weight: 600;
      transition: all 0.3s;
      text-transform: uppercase;
    }

    .header_aera .navbar-nav>li>a:hover {
      color: #f6b60b !important;
    }

    .navbar-toggle {
      margin-top: 15px;
      border-color: white;
    }

    .navbar-toggle .icon-bar {
      background-color: white;
    }

    /* Search Section */
    .search-section {
      color: black;
      padding: 60px 20px;
      text-align: center;
    }

    .search-box {
      max-width: 600px;
      margin: 0 auto;
      position: relative;
    }

    .search-box input {
      width: 100%;
      padding: 15px;
      border: 2px solid #000;
      border-radius: 8px;
      font-size: 16px;
    }

    .suggestions {
      background: #fff;
      color: #000;
      border: 1px solid #000;
      border-top: none;
      border-radius: 0 0 8px 8px;
      max-height: 150px;
      overflow-y: auto;
      position: absolute;
      width: 100%;
      z-index: 1000;
      text-align: left;
    }

    .suggestions div {
      padding: 10px;
      cursor: pointer;
    }

    .suggestions div:hover {
      background-color: #f0f0f0;
    }


    /* Lawyer Card - Professional Modern Design */
    .law-card {
      background: linear-gradient(to bottom right, #ffffff, #f4f7fb);
      border-radius: 20px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
      padding: 25px;
      margin-bottom: 30px;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      border: 1px solid #e0e0e0;
    }

    .law-card:hover {
      transform: translateY(-6px);
      box-shadow: 0 14px 28px rgba(0, 0, 0, 0.12);
    }

    .law-header {
      display: flex;
      align-items: center;
      gap: 15px;
      margin-bottom: 15px;
    }

    .law-header img {
      width: 80px;
      height: 80px;
      object-fit: cover;
      border-radius: 10px;

    }

    .law-name {
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      flex: 1;
    }

    .law-name h4 {
      font-size: 20px;
      margin-bottom: 5px;
      color: #333;
    }

    .law-name p {
      font-size: 13px;
      color: #666;
      margin: 0;
    }

    .view-btn {
      align-self: flex-start;
      background: #007bff;
      color: white;
      padding: 6px 12px;
      font-size: 13px;
      border: none;
      border-radius: 6px;
      text-decoration: none;
      margin-top: 5px;
      transition: background 0.3s ease;
    }

    .view-btn:hover {
      background: rgb(6, 6, 6);
      color: white;
    }

    .law-type {
      display: inline-block;
      padding: 6px 12px;
      background-color: #28a745;
      color: #fff;
      border-radius: 30px;
      font-size: 13px;
      margin-bottom: 10px;
    }

    .law-meta {
      font-size: 14px;
      color: #555;
      margin-bottom: 10px;
    }

    .law-meta i {
      margin-right: 5px;
      color: #007bff;
    }

    .languages span {
      display: inline-block;
      background: #e9f0ff;
      color: #0056b3;
      padding: 5px 10px;
      border-radius: 20px;
      margin: 3px 5px 5px 0;
      font-size: 12px;
    }

    .law-description {
      font-size: 14px;
      color: #444;
      margin-top: 10px;
      line-height: 1.5;
    }

    /* appointment btn  */
    .appointment-btn {
      display: block;
      margin-top: 15px;
      padding: 10px 15px;
      background-color: #28a745;
      color: white;
      text-align: center;
      border-radius: 5px;
      text-decoration: none;
      font-weight: bold;
      transition: all 0.3s ease;
    }

    .appointment-btn:hover {
      background-color: #218838;
      transform: translateY(-2px);
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
  </style>
</head>

<body>
  <nav class="navbar navbar-default header_aera">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#min_navbar">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="index.html">Star Law Firm</a>
      </div>
      <div class="collapse navbar-collapse" id="min_navbar">
        <ul class="nav navbar-nav navbar-right">
          <li><a href="index.php">Home</a></li>
          <li><a href="about.php">About</a></li>
          <li><a href="services.php">Services</a></li>
          <li><a href="contact.php">Contact</a></li>
          <li><a href="php/createprofile.php">Create Profile</a></li>
          <?php if (isset($_SESSION['user_email'])): ?>
            <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
          <?php endif; ?>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Search Section -->
  <section class="search-section">
    <h2 style="color:rgb(197, 11, 197); font-size: 90px; font-family: sans-serif; font-weight: 900;">Find a Lawyer</h2>
    <p style="color: white;"></p>
    <div class="search-box">
      <input type="text" id="searchInput" placeholder="Search by name, location, or case type." onkeyup="filterCards()" autocomplete="off">
      <div class="suggestions" id="suggestionsBox"></div>
    </div>
  </section>
  <!-- Lawyer Cards Section -->
 <div class="container my-5">
  <div class="row">
    <?php while ($row = $result->fetch_assoc()): ?>
      <div class="col-md-4">
        <div class="law-card" data-name="<?= htmlspecialchars($row['name']) ?>"
             data-location="<?= htmlspecialchars($row['location']) ?>"
             data-case="<?= htmlspecialchars($row['case_type']) ?>">
          <div class="law-header">
            <img src="php/<?= htmlspecialchars($row['image']) ?>" alt="Logo">
            <div class="law-name">
              <h4><?= htmlspecialchars($row['name']) ?><br>
                <p style="font-size: 12px;"><?= htmlspecialchars($row['location']) ?></p>
              </h4>
            </div>
          </div>
          <div class="law-type"
               style="display:inline-block; padding:4px 8px; background-color:#007bff; color:#fff; border-radius:5px; font-size:13px;">
            <?= htmlspecialchars($row['case_type']) ?>
          </div>
          <div class="law-meta">
            <p><i class="far fa-calendar-alt"></i> Founded in <?= htmlspecialchars($row['year_founded']) ?></p>
            <p><i class="fas fa-users"></i> <?= htmlspecialchars($row['team_size']) ?> people in team</p>
          </div>
          <div class="languages">
            <?php foreach (explode(',', $row['languages']) as $lang): ?>
              <span><?= htmlspecialchars(trim($lang)) ?></span>
            <?php endforeach; ?>
          </div>
          <p class="law-description">
            <?= htmlspecialchars($row['description']) ?>
          </p>

          <!-- ✅ FIXED BUTTON BELOW -->
          <a href="userlogin/form.php?lawyer_id=<?= $row['id'] ?>" class="appointment-btn">Get Appointment</a>

        </div>
      </div>
    <?php endwhile; ?>
  </div>
</div>




     <!--#start Our footer Area -->
       <?php include 'footer.php'; ?>
       
      <!--#End Our footer Area -->

  <script>
    function filterCards() {
      const input = document.getElementById('searchInput').value.toLowerCase();
      const cards = document.querySelectorAll('.law-card');
      const suggestionsBox = document.getElementById('suggestionsBox');
      suggestionsBox.innerHTML = '';

      let suggestions = [];

      cards.forEach(card => {
        const name = card.dataset.name.toLowerCase();
        const location = card.dataset.location.toLowerCase();
        const caseType = card.dataset.case.toLowerCase();

        const match = name.includes(input) || location.includes(input) || caseType.includes(input);

        if (match) {
          card.parentElement.style.display = 'block';

          if (input.length > 0 && !suggestions.includes(name)) {
            suggestions.push(name);
          }
        } else {
          card.parentElement.style.display = 'none';
        }
      });

      if (input.length > 0) {
        suggestions.forEach(suggestion => {
          const div = document.createElement('div');
          div.textContent = suggestion;
          div.onclick = () => {
            document.getElementById('searchInput').value = suggestion;
            suggestionsBox.innerHTML = '';
            filterCards();
          };
          suggestionsBox.appendChild(div);
        });
      }
    }
  </script>
  <!-- Bootstrap JS -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</body>

</html>