-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 12, 2025 at 02:00 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lawyer_website`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'faaiq', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `service_type` varchar(100) DEFAULT NULL,
  `urgency` varchar(100) DEFAULT NULL,
  `budget` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `appointment_date` date DEFAULT NULL,
  `appointment_time` time DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Pending',
  `user_id` int(11) DEFAULT NULL,
  `lawyer_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `first_name`, `last_name`, `email`, `phone`, `city`, `service_type`, `urgency`, `budget`, `description`, `created_at`, `appointment_date`, `appointment_time`, `status`, `user_id`, `lawyer_id`) VALUES
(7, 'Faaiq', 'aslam', 'faaiq@gmail.com', '03132275211', 'karachi', 'Family Law', 'This week', 'High', 'heleo im faaiq', '2025-06-08 07:51:50', '2025-06-08', '09:51:00', 'Pending', 1, 1),
(8, 'safa', 'aslam', 'aptech@gmail.com', '03132275211', 'islamabad', 'Family Law', 'This week', 'Low', 'hello', '2025-06-08 07:53:03', '2025-06-08', '09:52:00', 'Pending', 1, 1),
(9, 'safa', 'aslam', 'safa@gmail.com', '03132275211', 'karachi', 'Business Law', 'Immediately', 'Medium', 'hello my name is safa', '2025-06-08 07:55:42', '2025-06-08', '09:55:00', 'Pending', 1, 1),
(11, 'safa', 'Khan', 'faaiq@gmail.com', '03132275211', 'karachi', 'Family Law', 'Immediately', 'Medium', 'i dont know', '2025-06-08 08:20:11', '2025-06-08', '10:19:00', 'Pending', 1, 1),
(12, 'Hammad', 'khan', 'roshan45@gmail.com', '317534234', 'Karchi', 'Business Law', 'This week', 'Low', 'please contact me quick', '2025-06-09 10:37:48', NULL, NULL, 'Approved', 1, 14);

-- --------------------------------------------------------

--
-- Table structure for table `homepage_attorneys`
--

CREATE TABLE `homepage_attorneys` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `specialization` varchar(100) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `homepage_attorneys`
--

INSERT INTO `homepage_attorneys` (`id`, `name`, `specialization`, `photo`, `created_at`) VALUES
(4, 'Muhammad hasan', 'Family Lawyer', 'cricket 1.jpg', '2025-06-10 05:36:52'),
(5, 'Zia ul Haq', 'crminal lawyer', 'background 1.jpg', '2025-06-10 06:36:45'),
(6, 'Harry Tector', 'Family lawyer', 'background 2.jpg', '2025-06-10 06:37:24'),
(7, 'Chalie Chapline ', 'Corporate lawyer', 'about-main.png', '2025-06-10 15:42:38');

-- --------------------------------------------------------

--
-- Table structure for table `lawyers`
--

CREATE TABLE `lawyers` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `case_type` varchar(100) DEFAULT NULL,
  `year_founded` varchar(20) DEFAULT NULL,
  `team_size` varchar(50) DEFAULT NULL,
  `languages` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `is_approved` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lawyers`
--

INSERT INTO `lawyers` (`id`, `name`, `location`, `case_type`, `year_founded`, `team_size`, `languages`, `description`, `image`, `is_approved`) VALUES
(14, 'Faaiq', 'Karachi', 'Civil Case', '2008', '10', 'English urdu', 'Provide legal advice and consultation.', 'uploads/lawyer 1.jpeg', 1),
(16, 'abdullah', 'islamabad', 'divorce', '2000', '12', 'English', 'Specialize in different areas of law.', 'uploads/lawyer 2.jpeg', 1),
(17, 'sameer', 'lahore', 'criminial', '2000', '5', 'Urdu', 'Protect clients’ rights and interests.', 'uploads/lawyer 3.jpeg', 1),
(18, 'abdullah', 'islamabad', 'taalq', '24355', '22', 'english', 'vfasvfv', 'uploads/221.PNG', 1),
(19, 'Hasan Sheikh ', 'Quetta', 'Family Lawyer', '1999', '2', 'English', 'Hy  i am hasan', 'uploads/cricket 1.jpg', 1),
(20, 'Babarazam', 'sialkot', 'property lawyer', '2001', '7', 'urdu', 'hy please fast', 'uploads/background 1.jpg', 0),
(21, 'Zia ul Haq', 'Karachi', 'Family Lawyer', '1970', '11', 'urdu', 'i am zia', 'uploads/background 2.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `user_type` enum('user','lawyer','admin') NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `user_type`) VALUES
(1, 'faaiq', 'faaiq@gmail.com', 'faaiq123', 'user'),
(23, 'abdullah', 'abdullah@gmail.com', 'abdul123', 'user'),
(24, 'faaiq', 'safa@gmail.com', 'safa123', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `homepage_attorneys`
--
ALTER TABLE `homepage_attorneys`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lawyers`
--
ALTER TABLE `lawyers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `homepage_attorneys`
--
ALTER TABLE `homepage_attorneys`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `lawyers`
--
ALTER TABLE `lawyers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
